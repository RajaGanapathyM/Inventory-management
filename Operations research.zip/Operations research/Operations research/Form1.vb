﻿Imports System.Math
Imports System.IO


Public Class Form1
    Dim i, s, o, d, p, h, m, q, ct, pt, st, ip, lt, hs, pd, qs, qq, no, ro, ic, hc, oc, sc, tc, hhs, qqo, tc1, ii, iqq, itc, saf As Double
    Dim sh, eoq, moq, model, swtc, gbx As Integer
    Dim dvar, lvar As Integer
    Dim read As StreamReader
    Dim xval As Integer
    Dim zval(100, 100) As Double
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        model = 0
        lvar = 0
        dvar = 0
        gbx = 1
        xval = 0
        GroupBox3.BringToFront()
        ComboBox2.SelectedIndex = 0
        ComboBox3.SelectedIndex = 0
        ComboBox4.SelectedIndex = 0
        ComboBox5.SelectedIndex = 0
        ComboBox6.SelectedIndex = 0
        ComboBox12.SelectedIndex = 0
        ComboBox13.SelectedIndex = 0
        RadioButton3.Checked = True
        RadioButton6.Checked = True
        CheckBox5.BackColor = Color.Transparent
    End Sub
    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            m = 0
            p = 1
            TextBox6.Text = ""
            TextBox9.Text = ""
            TextBox10.Text = ""
            TextBox11.Text = ""
            TextBox26.Text = ""
            TextBox6.Enabled = False
            TextBox26.Enabled = False
            TextBox9.Enabled = False
            TextBox10.Enabled = False
            TextBox11.Enabled = False
            ComboBox4.Enabled = False
            model = 0
        End If
    End Sub
    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            TextBox6.Enabled = True
            TextBox26.Enabled = True
            TextBox9.Enabled = True
            TextBox10.Enabled = True
            TextBox11.Enabled = True
            ComboBox4.Enabled = True
            ComboBox4.SelectedIndex = 0
            model = 1
        End If
    End Sub
    Private Sub Button1_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs)
        'Call dat()
    End Sub
    Private Function compute() As Double
        Call dat()
        If CheckBox1.Checked = True Then
            hs = h + s
            hhs = hs / s
        Else
            hs = 1
            s = 1
            hhs = 1
        End If
        qs = 0
        If model = 0 Then
            qq = (Sqrt((2 * d * o) / h)) * (Sqrt(hs / s))

            TextBox11.Text = (qq - qs) / d
            ip = Val(TextBox11.Text)

            TextBox7.Text = qq
            m = TextBox7.Text

        ElseIf model = 1 Then
            pd = p - d
            qq = (Sqrt(2 * d * o / h)) * (Sqrt(hhs)) * (Sqrt(p / pd))

            TextBox10.Text = qq / p
            pt = TextBox10.Text

            TextBox11.Text = (qq - qs) / d
            ip = Val(TextBox11.Text)

            TextBox7.Text = (p - d) * pt
            m = TextBox7.Text

        End If

        TextBox14.Text = qq

        If model = 0 And CheckBox1.Checked = True Then
            qs = qq * (h / (hs))
            TextBox15.Text = qs

            TextBox7.Text = (qq - qs)
            m = TextBox7.Text

            TextBox11.Text = (qq - qs) / d
            ip = Val(TextBox11.Text)

        ElseIf model = 1 And CheckBox1.Checked = True Then

            qs = (qq * h * (1 - (d / p))) / hs
            TextBox15.Text = qs

            TextBox7.Text = (qq * (1 - (d / p))) - qs
            m = TextBox7.Text

            TextBox11.Text = (qq - qs) / d
            ip = Val(TextBox11.Text)

        End If

        If qq <> 0 Then

            TextBox12.Text = d / qq
            no = Val(TextBox12.Text)

            TextBox9.Text = 1 / no
            ct = Val(TextBox9.Text)

            TextBox13.Text = ct - ip
            st = Val(TextBox13.Text)

        End If
        If CheckBox2.Checked = True Then
            TextBox16.Text = (lt Mod ct) * d
            ro = TextBox16.Text
        End If

        saf = 0

        If lvar = 1 Or dvar = 1 Then
            Call rol()
        End If
        m = m + saf
        TextBox7.Text = m

        ro = ro + saf
        TextBox16.Text = ro

        TextBox36.Text = saf

        TextBox17.Text = d * i
        ic = Val(TextBox17.Text)

        TextBox19.Text = no * o
        oc = Val(TextBox19.Text)

        If model = 0 Then

            TextBox18.Text = (m / 2) * h
            hc = Val(TextBox18.Text)

            TextBox20.Text = (st / ct) * s * (qs / 2)
            sc = Val(TextBox20.Text)

        ElseIf model = 1 Then

            TextBox18.Text = (m / 2) * h * ip / ct
            hc = Val(TextBox18.Text)

            TextBox20.Text = (st / ct) * s * (qs / 2)
            sc = Val(TextBox20.Text)

        End If

        tc = ic + oc + hc + sc
        TextBox21.Text = tc

        Return qq
    End Function
    Private Function computec(ByVal raj As Double) As Double
        Call dat()
        If CheckBox1.Checked = True Then
            hs = h + s
            hhs = hs / s
        Else
            hs = 1
            s = 1
            hhs = 1
        End If
        qs = 0
        If model = 0 Then
            qq = raj

            TextBox11.Text = (qq - qs) / d
            ip = Val(TextBox11.Text)

            TextBox7.Text = qq
            m = TextBox7.Text

        ElseIf model = 1 Then
            qq = raj

            TextBox10.Text = qq / p
            pt = TextBox10.Text

            TextBox11.Text = (qq - qs) / d
            ip = Val(TextBox11.Text)

            TextBox7.Text = (p - d) * pt
            m = TextBox7.Text

        End If

        TextBox14.Text = qq

        If model = 0 And CheckBox1.Checked = True Then
            qs = qq * (h / (hs))
            TextBox15.Text = qs

            TextBox7.Text = (qq - qs)
            m = TextBox7.Text

        ElseIf model = 1 And CheckBox1.Checked = True Then

            qs = (qq * h * (1 - (d / p))) / hs
            TextBox15.Text = qs

            TextBox7.Text = (qq * (1 - (d / p))) - qs
            m = TextBox7.Text

        End If

        If qq <> 0 Then

            TextBox12.Text = d / qq
            no = Val(TextBox12.Text)

            TextBox9.Text = 1 / no
            ct = Val(TextBox9.Text)

            TextBox13.Text = ct - ip
            st = Val(TextBox13.Text)

        End If
        If CheckBox2.Checked = True Then
            TextBox16.Text = (lt Mod ct) * d
            ro = TextBox16.Text
        End If

        TextBox17.Text = d * i
        ic = Val(TextBox17.Text)

        TextBox19.Text = no * o
        oc = Val(TextBox19.Text)

        If model = 0 Then

            TextBox18.Text = (m / 2) * h
            hc = Val(TextBox18.Text)

            TextBox20.Text = (st / ct) * s * (qs / 2)
            sc = Val(TextBox20.Text)

        ElseIf model = 1 Then

            TextBox18.Text = (m / 2) * h * ip / ct
            hc = Val(TextBox18.Text)

            TextBox20.Text = (st / ct) * s * (qs / 2)
            sc = Val(TextBox20.Text)

        End If

        tc = ic + oc + hc + sc
        TextBox21.Text = tc

        Return qq
    End Function
    Private Function arrang() As Integer
        Dim ctgc, a, b, coun As Integer
        Dim ctg(), temp, a1, b1, s1, s2 As String

        ctgc = ComboBox1.Items.Count
        ReDim ctg(ctgc)

        temp = ComboBox1.Items(0)
        coun = ComboBox1.Items.Count
        For w = 0 To coun - 1
            ctg(w) = ComboBox1.Items(w)
        Next

        For w = 0 To coun - 1
            s1 = ctg(w)

            a = InStrRev(s1, "@") + 1
            a1 = Val(Mid(s1, a))

            For z = 0 To coun - 1
                s2 = ctg(z)

                b = InStrRev(s2, "@") + 1
                b1 = Val(Mid(s2, b))

                If Val(a1) < Val(b1) Then
                    temp = ctg(z)
                    ctg(z) = ctg(w)
                    ctg(w) = temp
                End If
            Next
        Next
        ComboBox1.Items.Clear()
        For w = 0 To coun - 1
            ComboBox1.Items.Add(ctg(w))
        Next


        Return qq

    End Function
    Private Function arrang2() As Integer
        Dim ctgc, a, b, coun As Integer
        Dim ctg(), ctg2(), temp, temp2, a1, b1, s1, s2 As String

        ctgc = ListBox5.Items.Count
        ReDim ctg(ctgc)
        ReDim ctg2(ctgc)

        temp = ListBox5.Items(0)
        coun = ListBox5.Items.Count
        For w = 0 To coun - 1
            ctg(w) = ListBox5.Items(w)
            ctg2(w) = ListBox4.Items(w)
        Next

        For w = 0 To coun - 1
            s1 = ctg(w)

            a = InStrRev(s1, "@") + 1
            a1 = Val(Mid(s1, a))

            For z = 0 To coun - 1
                s2 = ctg(z)

                b = InStrRev(s2, "@") + 1
                b1 = Val(Mid(s2, b))

                If Val(a1) < Val(b1) Then

                    temp = ctg(z)
                    ctg(z) = ctg(w)
                    ctg(w) = temp

                    temp2 = ctg2(z)
                    ctg2(z) = ctg2(w)
                    ctg2(w) = temp2

                End If
            Next
        Next
        ListBox5.Items.Clear()
        ListBox4.Items.Clear()
        For w = 0 To coun - 1
            ListBox5.Items.Add(ctg(w))
            ListBox4.Items.Add(ctg2(w))
        Next
        Return 1
    End Function
    Private Function pars(ByVal pine As String, ByVal k As Integer) As String
        Dim a, b As String
        Dim l, s, opes As String
        Dim res As String
        s = ""
        For iz = 1 To Len(pine)
            l = Mid(pine, iz, 1)
            If l = "+" Or l = "-" Or l = "*" Or l = "/" Then
                a = chng(s)
                s = ""
                opes = l
                For j = iz + 1 To Len(pine)
                    l = Mid(pine, j, 1)
                    If l = "+" Or l = "-" Or l = "*" Or l = "/" Or l = ")" Then
                        b = chng(s)
                        iz = j - 1
                        Exit For
                    ElseIf l = "(" Then
                        b = pars(Mid(pine, j + 1), k - 2)
                        s = b
                        j = InStrRev(pine, ")", k)
                        If j = 0 Then
                            Exit For
                        End If
                    End If
                    s = s + l
                Next
                Select Case (opes)
                    Case "+"
                        res = Val(a) + Val(b)
                        s = res
                        Continue For
                    Case "-"
                        res = Val(a) - Val(b)
                        s = res
                        Continue For
                    Case "*"
                        res = Val(a) * Val(b)
                        s = res
                        Continue For
                    Case "/"
                        res = Val(a) / Val(b)
                        s = res
                        Continue For
                    Case "^"
                        res = Val(res) ^ b
                        s = res
                        Continue For
                End Select
                Continue For
            ElseIf l = "(" Then
                res = pars(Mid(pine, iz + 1), k - 2)
                a = Val(res)
                iz = InStrRev(pine, ")", k)
                If iz = 0 Then
                    Return res
                End If

            ElseIf l = ")" Then
                If res = "" Then
                    If s <> "" Then
                        Return s
                    End If
                    res = pine
                End If
                Return res
            End If
            s = s + l
        Next
        If res = "" Then
            res = Val(pine)
        End If
        Return res
    End Function
    Private Function chng(ByVal s As String) As Double
        Dim a As Double
        a = Val(s)
        Select Case (s)
            Case "d"
                a = Val(pars(TextBox25.Text, Len(TextBox25.Text)))
                GoTo nf
            Case "i"
                a = Val(pars(TextBox2.Text, Len(TextBox2.Text)))
                GoTo nf
            Case "h"
                a = Val(pars(TextBox23.Text, Len(TextBox23.Text)))
                GoTo nf
            Case "o "
                a = Val(pars(TextBox4.Text, Len(TextBox4.Text)))
                GoTo nf
            Case "s "
                a = Val(pars(TextBox27.Text, Len(TextBox27.Text)))
                GoTo nf
            Case "p"
                a = Val(pars(TextBox26.Text, Len(TextBox26.Text)))
                GoTo nf
            Case "m "
                a = Val(pars(TextBox7.Text, Len(TextBox7.Text)))
                GoTo nf
            Case "lt"
                a = Val(pars(TextBox24.Text, Len(TextBox24.Text)))
                GoTo nf
            Case "ct"
                a = Val(pars(TextBox9.Text, Len(TextBox9.Text)))
                GoTo nf
            Case "pt"
                a = Val(pars(TextBox10.Text, Len(TextBox10.Text)))
                GoTo nf
            Case "ip"
                a = Val(pars(TextBox11.Text, Len(TextBox11.Text)))
                GoTo nf
            Case "no "
                a = Val(pars(TextBox12.Text, Len(TextBox12.Text)))
                GoTo nf
            Case "st "
                a = Val(pars(TextBox13.Text, Len(TextBox13.Text)))
                GoTo nf
            Case "qq "
                a = Val(pars(TextBox14.Text, Len(TextBox14.Text)))
                GoTo nf
            Case "qs "
                a = Val(pars(TextBox15.Text, Len(TextBox15.Text)))
                GoTo nf
            Case "ro "
                a = Val(pars(TextBox16.Text, Len(TextBox16.Text)))
                GoTo nf
            Case "ic "
                a = Val(pars(TextBox17.Text, Len(TextBox17.Text)))
                GoTo nf
            Case "hc"
                a = Val(pars(TextBox18.Text, Len(TextBox18.Text)))
                GoTo nf
            Case "oc "
                a = Val(pars(TextBox19.Text, Len(TextBox19.Text)))
                GoTo nf
            Case "sc "
                a = Val(pars(TextBox20.Text, Len(TextBox20.Text)))
                GoTo nf
            Case "tc "
                a = Val(pars(TextBox21.Text, Len(TextBox21.Text)))
                GoTo nf
        End Select
nf:
        Return a
    End Function
    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call arrang()
    End Sub
    Private Function dat() As Integer
        Call datbak()
        TextBox1.Text = Val(pars(TextBox1.Text, Len(TextBox1.Text)))
        TextBox2.Text = Val(pars(TextBox2.Text, Len(TextBox2.Text)))
        TextBox3.Text = Val(pars(TextBox3.Text, Len(TextBox3.Text)))
        TextBox4.Text = Val(pars(TextBox4.Text, Len(TextBox4.Text)))
        TextBox5.Text = Val(pars(TextBox5.Text, Len(TextBox5.Text)))
        TextBox6.Text = Val(pars(TextBox6.Text, Len(TextBox6.Text)))
        TextBox7.Text = Val(pars(TextBox7.Text, Len(TextBox7.Text)))
        TextBox8.Text = Val(pars(TextBox8.Text, Len(TextBox8.Text)))
        TextBox9.Text = Val(pars(TextBox9.Text, Len(TextBox9.Text)))
        TextBox10.Text = Val(pars(TextBox10.Text, Len(TextBox10.Text)))
        TextBox11.Text = Val(pars(TextBox11.Text, Len(TextBox11.Text)))
        TextBox12.Text = Val(pars(TextBox12.Text, Len(TextBox12.Text)))
        TextBox13.Text = Val(pars(TextBox13.Text, Len(TextBox13.Text)))
        TextBox14.Text = Val(pars(TextBox14.Text, Len(TextBox14.Text)))
        TextBox15.Text = Val(pars(TextBox15.Text, Len(TextBox15.Text)))
        TextBox16.Text = Val(pars(TextBox16.Text, Len(TextBox16.Text)))
        TextBox17.Text = Val(pars(TextBox17.Text, Len(TextBox17.Text)))
        TextBox18.Text = Val(pars(TextBox18.Text, Len(TextBox18.Text)))
        TextBox19.Text = Val(pars(TextBox19.Text, Len(TextBox19.Text)))
        TextBox20.Text = Val(pars(TextBox20.Text, Len(TextBox20.Text)))
        TextBox21.Text = Val(pars(TextBox21.Text, Len(TextBox21.Text)))
        Call datchng()
        d = Val(pars(TextBox1.Text, Len(TextBox1.Text)))
        i = Val(pars(TextBox2.Text, Len(TextBox2.Text)))
        h = Val(pars(TextBox3.Text, Len(TextBox3.Text)))
        o = Val(pars(TextBox4.Text, Len(TextBox4.Text)))
        s = Val(pars(TextBox5.Text, Len(TextBox5.Text)))
        p = Val(pars(TextBox6.Text, Len(TextBox6.Text)))
        m = Val(pars(TextBox7.Text, Len(TextBox7.Text)))
        lt = Val(pars(TextBox8.Text, Len(TextBox8.Text)))
        ct = Val(pars(TextBox9.Text, Len(TextBox9.Text)))
        pt = Val(pars(TextBox10.Text, Len(TextBox10.Text)))
        ip = Val(pars(TextBox11.Text, Len(TextBox11.Text)))
        no = Val(pars(TextBox12.Text, Len(TextBox12.Text)))
        st = Val(pars(TextBox13.Text, Len(TextBox13.Text)))
        qq = Val(pars(TextBox14.Text, Len(TextBox14.Text)))
        qs = Val(pars(TextBox15.Text, Len(TextBox15.Text)))
        ro = Val(pars(TextBox16.Text, Len(TextBox16.Text)))
        ic = Val(pars(TextBox17.Text, Len(TextBox17.Text)))
        hc = Val(pars(TextBox18.Text, Len(TextBox18.Text)))
        oc = Val(pars(TextBox19.Text, Len(TextBox19.Text)))
        sc = Val(pars(TextBox20.Text, Len(TextBox20.Text)))
        tc = Val(pars(TextBox21.Text, Len(TextBox21.Text)))
        Return 1
    End Function
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If CheckBox1.Checked = True Then
            hs = h + s
            hhs = hs / s
        Else
            hs = 1
            s = 1
            hhs = 1
        End If
    End Sub
    Private Function datbak() As Integer
        TextBox28.Text = Val(TextBox23.Text) / 100
        If CheckBox4.Checked = True Then
            TextBox3.Text = "(" + TextBox28.Text + "*i)"
        Else
            TextBox3.Text = TextBox23.Text
        End If
        TextBox28.Text = Val(TextBox25.Text) / 100
        If CheckBox5.Checked = True Then
            TextBox5.Text = "(" + TextBox28.Text + "*i)"
        Else
            TextBox5.Text = TextBox27.Text
        End If
        Return 1
    End Function
    Private Function datchng() As Integer

        TextBox1.Text = Val(TextBox1.Text) * Val(ListBox6.Items(ComboBox3.SelectedIndex))
        TextBox3.Text = Val(TextBox3.Text) * Val(ListBox6.Items(ComboBox5.SelectedIndex))
        TextBox5.Text = Val(TextBox5.Text) * Val(ListBox6.Items(ComboBox6.SelectedIndex))
        TextBox6.Text = Val(TextBox6.Text) * Val(ListBox6.Items(ComboBox4.SelectedIndex))
        TextBox8.Text = Val(TextBox8.Text) / Val(ListBox6.Items(ComboBox2.SelectedIndex))
        Return 0
    End Function
    Private Function rol() As Integer
        saf = 0
       
        If dvar = 1 Then
            If CheckBox2.Checked Then
                TextBox33.Text = Val(TextBox33.Text) * Sqrt((Val(TextBox8.Text) * Val(ListBox6.Items(ComboBox12.SelectedIndex))))
            End If
            saf = saf + Val(TextBox32.Text) * Val(TextBox33.Text)
        End If
        If lvar = 1 Then
            If CheckBox2.Checked Then
                TextBox35.Text = Val(TextBox35.Text) / Val(ListBox6.Items(ComboBox13.SelectedIndex))
            End If
            saf = saf + Val(TextBox34.Text) * Val(TextBox35.Text) * d
        End If

        Return 0

    End Function
    Private Sub TextBox25_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

        MsgBox(TextBox25.Text)

    End Sub
    Private Sub CheckBox1_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            s = 0
            TextBox5.Text = ""
            TextBox27.Text = ""
            TextBox5.Enabled = False
            TextBox27.Enabled = False
            CheckBox5.Enabled = False
            CheckBox5.BackColor = Color.Transparent
            ComboBox6.Enabled = False
        ElseIf CheckBox1.Checked = True Then
            TextBox5.Enabled = True
            TextBox27.Enabled = True
            CheckBox5.Enabled = True
            CheckBox5.BackColor = Color.White
            ComboBox6.Enabled = True
            ComboBox6.SelectedIndex = 0
        End If
    End Sub
    Private Sub RadioButton3_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        lvar = 0
        TextBox34.Enabled = False
        TextBox35.Enabled = False
        ComboBox13.Enabled = False
    End Sub
    Private Sub TextBox24_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox24.TextChanged
        TextBox8.Text = TextBox24.Text
    End Sub
    Private Sub TextBox26_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox26.TextChanged
        TextBox6.Text = TextBox26.Text
    End Sub
    Private Sub TextBox31_KeyPress1(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox31.KeyPress
        Dim toi As Integer

        If Asc(e.KeyChar) = 13 Then
            If toi > 0 Then
                TextBox31.Text = Mid(TextBox31.Text, 1, toi - 1)
            End If
            TextBox22.Text = TextBox29.Text + "-" + TextBox30.Text + "@" + TextBox31.Text
            ComboBox1.Items.Add(TextBox22.Text)
            TextBox22.Clear()
            TextBox29.Text = ""
            TextBox30.Text = ""
            TextBox31.Text = ""
            TextBox29.Focus()
        End If
        If ComboBox1.Items.Count = 0 Then
            Button3.Enabled = False
        Else
            Button3.Enabled = True
        End If
    End Sub
    Private Sub TextBox31_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox31.TextChanged
        If TextBox29.Text = "" Or TextBox31.Text = "" Then
            Button2.Enabled = False
        Else
            Button2.Enabled = True
        End If
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim ti, tis As String

        TextBox22.Text = ComboBox1.Items(ComboBox1.SelectedIndex)

        For toi = 1 To Len(TextBox22.Text)
            ti = Mid(TextBox22.Text, toi, 1)
            If ti = "-" Then
                TextBox29.Text = tis
                tis = ""
                Continue For
            ElseIf ti = "@" Then
                TextBox30.Text = tis
                tis = ""
                Continue For
            End If
            tis = tis + ti
        Next
        TextBox31.Text = tis

        ComboBox1.Items.RemoveAt(ComboBox1.SelectedIndex)
        Button2.Enabled = True

        If ComboBox1.Items.Count = 0 Then
            Button3.Enabled = False
        Else
            Button3.Enabled = True
        End If

    End Sub
    Private Sub TextBox2_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        ComboBox1.Items.Clear()
    End Sub
    Private Sub TextBox25_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox25.TextChanged
        TextBox1.Text = TextBox25.Text
    End Sub
    Private Sub CheckBox2_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = False Then
            lt = 0
            TextBox8.Text = ""
            TextBox24.Text = ""
            TextBox8.Enabled = False
            TextBox24.Enabled = False
            ComboBox2.Enabled = False
        ElseIf CheckBox2.Checked = True Then
            TextBox8.Enabled = True
            TextBox24.Enabled = True
            ComboBox2.Enabled = True
        End If
    End Sub
    Private Sub Button3_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Call arrang()
    End Sub
    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim toi As Integer
        toi = InStr(TextBox31.Text, "%")
        If toi > 0 Then
            TextBox31.Text = Mid(TextBox31.Text, 1, toi - 1)
            TextBox31.Text = Val(TextBox2.Text) - (Val(TextBox2.Text) * (Val(TextBox31.Text) / 100))
        End If

        TextBox22.Text = TextBox29.Text + "-" + TextBox30.Text + "@" + TextBox31.Text
        ComboBox1.Items.Add(TextBox22.Text)
        TextBox22.Clear()
        TextBox29.Text = ""
        TextBox30.Text = ""
        TextBox31.Text = ""
        TextBox29.Focus()

    End Sub
    Private Sub CheckBox3_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            TextBox22.Enabled = True
            TextBox29.Enabled = True
            TextBox30.Enabled = True
            TextBox31.Enabled = True
        Else
            TextBox2.Enabled = True
            TextBox22.Enabled = False
            TextBox29.Enabled = False
            TextBox30.Enabled = False
            TextBox31.Enabled = False
            ComboBox1.Items.Clear()
        End If
    End Sub
    Private Sub TextBox23_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox23.TextChanged
        TextBox3.Text = TextBox23.Text
    End Sub
    Private Sub TextBox27_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox27.TextChanged
        TextBox5.Text = TextBox27.Text
    End Sub
    Private Sub ComboBox7_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox7.SelectedIndexChanged
        TextBox13.Text = Val(st) * Val(ListBox6.Items(ComboBox7.SelectedIndex))
    End Sub
    Private Sub ComboBox8_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox8.SelectedIndexChanged
        TextBox9.Text = Val(ct) * Val(ListBox6.Items(ComboBox8.SelectedIndex))
    End Sub
    Private Sub ComboBox9_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox9.SelectedIndexChanged
        TextBox10.Text = Val(pt) * Val(ListBox6.Items(ComboBox9.SelectedIndex))
    End Sub
    Private Sub ComboBox10_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox10.SelectedIndexChanged
        TextBox11.Text = Val(ip) * Val(ListBox6.Items(ComboBox10.SelectedIndex))
    End Sub
    Private Sub ComboBox11_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox11.SelectedIndexChanged
        TextBox12.Text = Val(no) / Val(ListBox6.Items(ComboBox11.SelectedIndex))
    End Sub
    Private Sub TextBox29_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox29.TextChanged
        If TextBox29.Text = "" Or TextBox31.Text = "" Then
            Button2.Enabled = False
        Else
            Button2.Enabled = True
        End If
    End Sub
    Private Sub TextBox30_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox30.TextChanged
        If TextBox29.Text = "" Or TextBox31.Text = "" Then
            Button2.Enabled = False
        Else
            Button2.Enabled = True
        End If
    End Sub
    Private Sub RadioButton4_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton4.CheckedChanged
        lvar = 1
        TextBox34.Enabled = True
        TextBox35.Enabled = True
        ComboBox13.Enabled = True
    End Sub
    Private Sub RadioButton6_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton6.CheckedChanged
        dvar = 0
        TextBox32.Enabled = False
        TextBox33.Enabled = False
        ComboBox12.Enabled = False
    End Sub
    Private Sub RadioButton5_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton5.CheckedChanged
        dvar = 1
        TextBox32.Enabled = True
        TextBox33.Enabled = True
        ComboBox12.Enabled = True
    End Sub
    Private Function grpbx(ByVal vl) As Integer
        Select Case (vl)
            Case 1
                GroupBox3.BringToFront()
                GoTo nd
            Case 2
                GroupBox4.BringToFront()
                GoTo nd
            Case 3
                GroupBox6.BringToFront()
                GoTo nd
            Case 4
                GroupBox8.BringToFront()
                GoTo nd
            Case 5
                GroupBox7.BringToFront()
                GoTo nd
        End Select



nd:
        Return 0
    End Function
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        gbx = gbx + 1
        Call grpbx(gbx)
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        gbx = gbx - 1
        Call grpbx(gbx)
    End Sub
    Private Function zvaluup() As Integer
        Dim valu, xs As String

        Dim xz, xj, xi As Integer
        xi = 1
        xj = 1
        xz = 0
        read = New StreamReader("C:\OR\Ztable.txt")
        valu = read.ReadToEnd
        read.Close()

        For xx = 0 To Len(valu) - 1


            If valu(xx) = "." Then
                xs = "0." + xs
                zval(xi, xj) = Val(xs)
                xj = xj + 1
                If xj > 10 Then
                    xj = 1
                    xi = xi + 1
                    'If xi >= 15 Then
                    'End If
                End If
                xs = ""
                Continue For

            End If
            xs = xs + valu(xx)
        Next
        Return 0
    End Function
    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        Dim pz, zvi, zvd, zvr, zvr2 As Double
        Dim xi1, xj1 As Integer

        If xval = 0 Then
            Call zvaluup()
            xval = 1
        End If

        pz = NumericUpDown1.Value / 100

        If Val(pz) < 0.00005 Then
            zvr = -3.9
            GoTo ndd
        End If
        For xi1 = 79 To 1 Step -1
            For xj1 = 10 To 1 Step -1

                If Val(pz) = Val(zval(xi1, xj1)) Then
                    zvi = 3.9 - ((79 - xi1) / 10)
                    zvd = (xj1 - 1) / 100
                    zvr = zvi + zvd
                    Exit For
                ElseIf Val(pz) > Val(zval(xi1, xj1)) Then
                    zvi = 3.9 - ((79 - xi1) / 10)
                    zvd = (xj1 - 1) / 100
                    zvr = zvi + zvd

                    zvi = 3.9 - ((79 - xi1) / 10)
                    zvd = (xj1) / 100
                    zvr2 = zvi + zvd

                    zvr = (zvr + zvr2) / 2
                    GoTo ndd
                End If
            Next
        Next
ndd:
        TextBox32.Text = zvr
        TextBox34.Text = zvr

    End Sub
    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim max, min As Double
        Dim strn, lk As String
        Dim z As Integer
        swtc = 1
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        ListBox4.Items.Clear()
        ListBox5.Items.Clear()
        ComboBox7.SelectedIndex = 0
        ComboBox8.SelectedIndex = 0
        ComboBox9.SelectedIndex = 0
        ComboBox10.SelectedIndex = 0
        ComboBox11.SelectedIndex = 0
        If CheckBox3.Checked = True Then
            Call arrang()
            lk = ""
            For w = 0 To ComboBox1.Items.Count - 1
                lk = ""
                strn = ComboBox1.Items(w)
                z = 0
                For x = 0 To Len(strn) - 1
                    If strn(x) = "-" Then
                        ListBox1.Items.Add(lk)
                        lk = ""
                        Continue For
                    ElseIf strn(x) = "@" Then
                        If lk = "" Then
                            ListBox2.Items.Add("infinity")
                        Else
                            ListBox2.Items.Add(lk)
                        End If
                        lk = ""
                        Continue For
                    End If
                    lk = lk + strn(x)
                Next
                ListBox3.Items.Add(lk)
            Next
            For w = 0 To ListBox1.Items.Count - 1
                TextBox2.Text = ListBox3.Items(w)
                Call compute()
                min = Val(ListBox1.Items(w))
                max = Val(ListBox2.Items(w))
                If qq >= min Then
                    If qq <= max Or ListBox2.Items(w) = "infinity" Then
                        ListBox4.Items.Add(ListBox3.Items(w))
                        ListBox5.Items.Add(tc)
                    End If
                Else
                    Call computec(Val(ListBox1.Items(w)))
                    ListBox4.Items.Add(ListBox3.Items(w))
                    ListBox5.Items.Add(tc)
                End If
            Next
            Call arrang2()
            TextBox2.Text = ListBox4.Items(0)
            Call compute()
            For w = 0 To ListBox3.Items.Count - 1
                If ListBox3.Items(w) = TextBox2.Text Then
                    z = w
                End If
            Next
            min = Val(ListBox1.Items(z))
            max = Val(ListBox2.Items(z))
            If qq >= min Then
                If qq <= max Or ListBox2.Items(z) = "infinity" Then
                    ListBox4.Items.Add(ListBox3.Items(z))
                    ListBox5.Items.Add(tc)
                End If
            Else
                Call computec(Val(ListBox1.Items(z)))
                ListBox4.Items.Add(ListBox3.Items(z))
                ListBox5.Items.Add(tc)
            End If
            GoTo nd
        End If
        Call compute()

        TextBox23.Text = Val(TextBox3.Text) / Val(ListBox6.Items(ComboBox5.SelectedIndex))
        TextBox27.Text = Val(TextBox5.Text) / Val(ListBox6.Items(ComboBox6.SelectedIndex))
        swtc = 0
nd:
    End Sub
End Class
