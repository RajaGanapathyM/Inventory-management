﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.ComboBox12 = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.r = New System.Windows.Forms.Label()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.ListBox6 = New System.Windows.Forms.ListBox()
        Me.RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ListBox5 = New System.Windows.Forms.ListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.ListBox4 = New System.Windows.Forms.ListBox()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TextBox67 = New System.Windows.Forms.TextBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TextBox62 = New System.Windows.Forms.TextBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.ListBox18 = New System.Windows.Forms.ListBox()
        Me.ListBox42 = New System.Windows.Forms.ListBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.ListBox14 = New System.Windows.Forms.ListBox()
        Me.ListBox15 = New System.Windows.Forms.ListBox()
        Me.ListBox16 = New System.Windows.Forms.ListBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.ListBox17 = New System.Windows.Forms.ListBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.ListBox55 = New System.Windows.Forms.ListBox()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.ListBox31 = New System.Windows.Forms.ListBox()
        Me.ListBox32 = New System.Windows.Forms.ListBox()
        Me.ListBox33 = New System.Windows.Forms.ListBox()
        Me.ListBox34 = New System.Windows.Forms.ListBox()
        Me.ListBox35 = New System.Windows.Forms.ListBox()
        Me.ListBox36 = New System.Windows.Forms.ListBox()
        Me.ListBox37 = New System.Windows.Forms.ListBox()
        Me.ListBox38 = New System.Windows.Forms.ListBox()
        Me.ListBox39 = New System.Windows.Forms.ListBox()
        Me.ListBox40 = New System.Windows.Forms.ListBox()
        Me.ListBox41 = New System.Windows.Forms.ListBox()
        Me.ListBox43 = New System.Windows.Forms.ListBox()
        Me.ListBox44 = New System.Windows.Forms.ListBox()
        Me.ListBox45 = New System.Windows.Forms.ListBox()
        Me.ListBox46 = New System.Windows.Forms.ListBox()
        Me.ListBox47 = New System.Windows.Forms.ListBox()
        Me.ListBox48 = New System.Windows.Forms.ListBox()
        Me.ListBox49 = New System.Windows.Forms.ListBox()
        Me.ListBox50 = New System.Windows.Forms.ListBox()
        Me.ListBox51 = New System.Windows.Forms.ListBox()
        Me.ListBox52 = New System.Windows.Forms.ListBox()
        Me.ListBox53 = New System.Windows.Forms.ListBox()
        Me.ListBox54 = New System.Windows.Forms.ListBox()
        Me.ListBox19 = New System.Windows.Forms.ListBox()
        Me.ListBox20 = New System.Windows.Forms.ListBox()
        Me.ListBox21 = New System.Windows.Forms.ListBox()
        Me.ListBox22 = New System.Windows.Forms.ListBox()
        Me.ListBox23 = New System.Windows.Forms.ListBox()
        Me.ListBox24 = New System.Windows.Forms.ListBox()
        Me.ListBox25 = New System.Windows.Forms.ListBox()
        Me.ListBox26 = New System.Windows.Forms.ListBox()
        Me.ListBox27 = New System.Windows.Forms.ListBox()
        Me.ListBox28 = New System.Windows.Forms.ListBox()
        Me.ListBox29 = New System.Windows.Forms.ListBox()
        Me.ListBox30 = New System.Windows.Forms.ListBox()
        Me.ListBox13 = New System.Windows.Forms.ListBox()
        Me.ListBox11 = New System.Windows.Forms.ListBox()
        Me.ListBox12 = New System.Windows.Forms.ListBox()
        Me.ListBox9 = New System.Windows.Forms.ListBox()
        Me.ListBox10 = New System.Windows.Forms.ListBox()
        Me.ListBox8 = New System.Windows.Forms.ListBox()
        Me.ListBox7 = New System.Windows.Forms.ListBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        Me.RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.TextBox65 = New System.Windows.Forms.TextBox()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.RadioButton8 = New System.Windows.Forms.RadioButton()
        Me.RadioButton7 = New System.Windows.Forms.RadioButton()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.SuspendLayout()
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RadioButton1.Location = New System.Drawing.Point(179, 41)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(201, 33)
        Me.RadioButton1.TabIndex = 1
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Purchase Model"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.BackColor = System.Drawing.Color.White
        Me.CheckBox5.Enabled = False
        Me.CheckBox5.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.CheckBox5.Location = New System.Drawing.Point(788, 72)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(51, 25)
        Me.CheckBox5.TabIndex = 16
        Me.CheckBox5.Text = "%I"
        Me.CheckBox5.UseVisualStyleBackColor = False
        '
        'TextBox21
        '
        Me.TextBox21.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox21.ForeColor = System.Drawing.Color.White
        Me.TextBox21.Location = New System.Drawing.Point(423, 459)
        Me.TextBox21.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.ReadOnly = True
        Me.TextBox21.Size = New System.Drawing.Size(235, 36)
        Me.TextBox21.TabIndex = 45
        Me.TextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox27
        '
        Me.TextBox27.Enabled = False
        Me.TextBox27.Location = New System.Drawing.Point(314, 168)
        Me.TextBox27.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(258, 36)
        Me.TextBox27.TabIndex = 103
        '
        'ComboBox5
        '
        Me.ComboBox5.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Items.AddRange(New Object() {"/unit/Year", "/unit/Month", "/unit/Week", "/unit/Day"})
        Me.ComboBox5.Location = New System.Drawing.Point(514, 70)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(93, 28)
        Me.ComboBox5.TabIndex = 100
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Snow
        Me.Label20.Location = New System.Drawing.Point(217, 462)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(160, 28)
        Me.Label20.TabIndex = 115
        Me.Label20.Text = "Total Cost(TC)"
        '
        'ComboBox4
        '
        Me.ComboBox4.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Items.AddRange(New Object() {"/Year", "/Month", "/Week", "/Day"})
        Me.ComboBox4.Location = New System.Drawing.Point(1027, 70)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(95, 28)
        Me.ComboBox4.TabIndex = 98
        '
        'TextBox26
        '
        Me.TextBox26.Enabled = False
        Me.TextBox26.Location = New System.Drawing.Point(314, 203)
        Me.TextBox26.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(258, 36)
        Me.TextBox26.TabIndex = 99
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Snow
        Me.Label19.Location = New System.Drawing.Point(716, 397)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(198, 28)
        Me.Label19.TabIndex = 114
        Me.Label19.Text = "Shortage Cost(SC)"
        '
        'ComboBox3
        '
        Me.ComboBox3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ComboBox3.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"/Year", "/Month", "/Week", "/Day"})
        Me.ComboBox3.Location = New System.Drawing.Point(181, 70)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(101, 28)
        Me.ComboBox3.TabIndex = 100
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(314, 28)
        Me.TextBox25.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(258, 36)
        Me.TextBox25.TabIndex = 97
        '
        'ComboBox2
        '
        Me.ComboBox2.Enabled = False
        Me.ComboBox2.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"Years", "Months", "Weeks", "Days"})
        Me.ComboBox2.Location = New System.Drawing.Point(1214, 70)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(91, 28)
        Me.ComboBox2.TabIndex = 94
        '
        'TextBox36
        '
        Me.TextBox36.Enabled = False
        Me.TextBox36.Location = New System.Drawing.Point(423, 397)
        Me.TextBox36.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(235, 36)
        Me.TextBox36.TabIndex = 40
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Snow
        Me.Label36.Location = New System.Drawing.Point(217, 397)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(179, 28)
        Me.Label36.TabIndex = 117
        Me.Label36.Text = "Safety Stock(SS)"
        '
        'TextBox24
        '
        Me.TextBox24.Enabled = False
        Me.TextBox24.Location = New System.Drawing.Point(314, 238)
        Me.TextBox24.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(258, 36)
        Me.TextBox24.TabIndex = 95
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.CheckBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox4.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.CheckBox4.Location = New System.Drawing.Point(464, 71)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(48, 25)
        Me.CheckBox4.TabIndex = 13
        Me.CheckBox4.Text = "%I"
        Me.CheckBox4.UseVisualStyleBackColor = False
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(314, 98)
        Me.TextBox23.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(258, 36)
        Me.TextBox23.TabIndex = 93
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Snow
        Me.Label16.Location = New System.Drawing.Point(711, 362)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(203, 28)
        Me.Label16.TabIndex = 113
        Me.Label16.Text = "Ordering Cost(OC)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label8.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(113, 238)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(151, 28)
        Me.Label8.TabIndex = 91
        Me.Label8.Text = "Lead Time(L)"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Snow
        Me.Label17.Location = New System.Drawing.Point(726, 328)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(188, 28)
        Me.Label17.TabIndex = 112
        Me.Label17.Text = "Holding cost(HC)"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Snow
        Me.Label18.Location = New System.Drawing.Point(764, 295)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(150, 28)
        Me.Label18.TabIndex = 111
        Me.Label18.Text = "Item Cost(IC)"
        '
        'TextBox8
        '
        Me.TextBox8.Enabled = False
        Me.TextBox8.Location = New System.Drawing.Point(314, 238)
        Me.TextBox8.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(258, 36)
        Me.TextBox8.TabIndex = 90
        '
        'TextBox6
        '
        Me.TextBox6.Enabled = False
        Me.TextBox6.Location = New System.Drawing.Point(314, 203)
        Me.TextBox6.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(258, 36)
        Me.TextBox6.TabIndex = 89
        '
        'TextBox5
        '
        Me.TextBox5.Enabled = False
        Me.TextBox5.Location = New System.Drawing.Point(314, 168)
        Me.TextBox5.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(258, 36)
        Me.TextBox5.TabIndex = 88
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(941, 43)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(235, 59)
        Me.Button1.TabIndex = 27
        Me.Button1.Text = "Compute"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox20
        '
        Me.TextBox20.Enabled = False
        Me.TextBox20.Location = New System.Drawing.Point(941, 394)
        Me.TextBox20.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(235, 36)
        Me.TextBox20.TabIndex = 44
        '
        'TextBox19
        '
        Me.TextBox19.Enabled = False
        Me.TextBox19.Location = New System.Drawing.Point(941, 359)
        Me.TextBox19.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(235, 36)
        Me.TextBox19.TabIndex = 43
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(299, 116)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(119, 36)
        Me.TextBox33.TabIndex = 97
        '
        'TextBox18
        '
        Me.TextBox18.Enabled = False
        Me.TextBox18.Location = New System.Drawing.Point(941, 325)
        Me.TextBox18.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(235, 36)
        Me.TextBox18.TabIndex = 42
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(314, 133)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(258, 36)
        Me.TextBox4.TabIndex = 87
        '
        'ComboBox13
        '
        Me.ComboBox13.Enabled = False
        Me.ComboBox13.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Items.AddRange(New Object() {"Year", "Month", "Week", "Days"})
        Me.ComboBox13.Location = New System.Drawing.Point(466, 64)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(81, 28)
        Me.ComboBox13.TabIndex = 109
        '
        'TextBox17
        '
        Me.TextBox17.Enabled = False
        Me.TextBox17.Location = New System.Drawing.Point(941, 292)
        Me.TextBox17.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(235, 36)
        Me.TextBox17.TabIndex = 41
        '
        'ComboBox12
        '
        Me.ComboBox12.Enabled = False
        Me.ComboBox12.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Items.AddRange(New Object() {"/Year", "/Month", "/Week", "/Days"})
        Me.ComboBox12.Location = New System.Drawing.Point(279, 64)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(86, 28)
        Me.ComboBox12.TabIndex = 104
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Snow
        Me.Label15.Location = New System.Drawing.Point(195, 362)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(201, 28)
        Me.Label15.TabIndex = 110
        Me.Label15.Text = "Reorder level(RO)"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.DecimalPlaces = 3
        Me.NumericUpDown1.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown1.Location = New System.Drawing.Point(230, 47)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(165, 36)
        Me.NumericUpDown1.TabIndex = 108
        Me.NumericUpDown1.ThousandsSeparator = True
        Me.NumericUpDown1.Value = New Decimal(New Integer() {95, 0, 0, 0})
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.TextBox33)
        Me.GroupBox9.Controls.Add(Me.NumericUpDown1)
        Me.GroupBox9.Controls.Add(Me.Label37)
        Me.GroupBox9.Controls.Add(Me.Label35)
        Me.GroupBox9.Controls.Add(Me.Label34)
        Me.GroupBox9.Controls.Add(Me.Label32)
        Me.GroupBox9.Controls.Add(Me.Label33)
        Me.GroupBox9.Controls.Add(Me.TextBox34)
        Me.GroupBox9.Controls.Add(Me.TextBox35)
        Me.GroupBox9.Controls.Add(Me.Label31)
        Me.GroupBox9.Controls.Add(Me.Label30)
        Me.GroupBox9.Controls.Add(Me.TextBox32)
        Me.GroupBox9.Dock = System.Windows.Forms.DockStyle.Right
        Me.GroupBox9.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox9.Font = New System.Drawing.Font("Cambria", 18.0!)
        Me.GroupBox9.Location = New System.Drawing.Point(781, 1466)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(558, 0)
        Me.GroupBox9.TabIndex = 121
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Data"
        Me.GroupBox9.Visible = False
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label37.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(11, 49)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(213, 28)
        Me.Label37.TabIndex = 106
        Me.Label37.Text = "Service Level(in %)"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label35.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(11, 203)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(148, 28)
        Me.Label35.TabIndex = 105
        Me.Label35.Text = "For lead time"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label34.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(11, 88)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(143, 28)
        Me.Label34.TabIndex = 104
        Me.Label34.Text = "For Demand "
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label32.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(349, 203)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(26, 28)
        Me.Label32.TabIndex = 103
        Me.Label32.Text = "σ"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label33.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(227, 203)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(25, 28)
        Me.Label33.TabIndex = 102
        Me.Label33.Text = "Z"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(187, 239)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(106, 36)
        Me.TextBox34.TabIndex = 100
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(299, 239)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(119, 36)
        Me.TextBox35.TabIndex = 101
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label31.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(349, 88)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(26, 28)
        Me.Label31.TabIndex = 99
        Me.Label31.Text = "σ"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label30.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(225, 87)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(25, 28)
        Me.Label30.TabIndex = 98
        Me.Label30.Text = "Z"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(187, 117)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(106, 36)
        Me.TextBox32.TabIndex = 96
        '
        'TextBox16
        '
        Me.TextBox16.Enabled = False
        Me.TextBox16.Location = New System.Drawing.Point(423, 362)
        Me.TextBox16.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(235, 36)
        Me.TextBox16.TabIndex = 39
        '
        'TextBox14
        '
        Me.TextBox14.Enabled = False
        Me.TextBox14.Location = New System.Drawing.Point(423, 295)
        Me.TextBox14.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(235, 36)
        Me.TextBox14.TabIndex = 37
        '
        'TextBox15
        '
        Me.TextBox15.Enabled = False
        Me.TextBox15.Location = New System.Drawing.Point(423, 328)
        Me.TextBox15.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(235, 36)
        Me.TextBox15.TabIndex = 38
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Snow
        Me.Label13.Location = New System.Drawing.Point(99, 328)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(297, 28)
        Me.Label13.TabIndex = 108
        Me.Label13.Text = "Optimum Shortage size(QS)"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Snow
        Me.Label14.Location = New System.Drawing.Point(129, 295)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(267, 28)
        Me.Label14.TabIndex = 107
        Me.Label14.Text = "Optimum order size(QQ)"
        '
        'ComboBox11
        '
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Items.AddRange(New Object() {"/Year", "/Month", "/Week", "/Day"})
        Me.ComboBox11.Location = New System.Drawing.Point(560, 124)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(98, 36)
        Me.ComboBox11.TabIndex = 99
        '
        'ComboBox10
        '
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Items.AddRange(New Object() {"Year", "Month", "Week", "Days"})
        Me.ComboBox10.Location = New System.Drawing.Point(1078, 194)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(98, 36)
        Me.ComboBox10.TabIndex = 98
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Items.AddRange(New Object() {"Year", "Month", "Week", "Days"})
        Me.ComboBox9.Location = New System.Drawing.Point(1078, 159)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(98, 36)
        Me.ComboBox9.TabIndex = 97
        '
        'ComboBox8
        '
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Items.AddRange(New Object() {"Year", "Month", "Week", "Days"})
        Me.ComboBox8.Location = New System.Drawing.Point(1078, 125)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(98, 36)
        Me.ComboBox8.TabIndex = 96
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label5.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(87, 168)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(184, 28)
        Me.Label5.TabIndex = 82
        Me.Label5.Text = "Shortage Cost(S)"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label4.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(139, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 28)
        Me.Label4.TabIndex = 81
        Me.Label4.Text = "Demand(D)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label3.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(114, 133)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(157, 28)
        Me.Label3.TabIndex = 80
        Me.Label3.Text = "Order Cost(O)"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label2.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(94, 98)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(177, 28)
        Me.Label2.TabIndex = 79
        Me.Label2.Text = "Holding Cost(H)"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Snow
        Me.Label10.Location = New System.Drawing.Point(687, 194)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(227, 28)
        Me.Label10.TabIndex = 92
        Me.Label10.Text = "Inventory Period(IP)"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(314, 98)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(258, 36)
        Me.TextBox3.TabIndex = 86
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(314, 63)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(258, 36)
        Me.TextBox2.TabIndex = 85
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label6.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(60, 203)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(211, 28)
        Me.Label6.TabIndex = 83
        Me.Label6.Text = "Production Rate(P)"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label1.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(135, 63)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 28)
        Me.Label1.TabIndex = 78
        Me.Label1.Text = "Item Cost(I)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(314, 28)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(258, 36)
        Me.TextBox1.TabIndex = 84
        '
        'ComboBox7
        '
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Items.AddRange(New Object() {"Year", "Month", "Week", "Days"})
        Me.ComboBox7.Location = New System.Drawing.Point(560, 194)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(98, 36)
        Me.ComboBox7.TabIndex = 95
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Snow
        Me.Label12.Location = New System.Drawing.Point(196, 194)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(200, 28)
        Me.Label12.TabIndex = 94
        Me.Label12.Text = "Shortage time(ST)"
        '
        'TextBox13
        '
        Me.TextBox13.Enabled = False
        Me.TextBox13.Location = New System.Drawing.Point(423, 194)
        Me.TextBox13.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(235, 36)
        Me.TextBox13.TabIndex = 33
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Snow
        Me.Label11.Location = New System.Drawing.Point(152, 124)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(244, 28)
        Me.Label11.TabIndex = 93
        Me.Label11.Text = "Number of orders(NO)"
        '
        'TextBox12
        '
        Me.TextBox12.Enabled = False
        Me.TextBox12.Location = New System.Drawing.Point(423, 124)
        Me.TextBox12.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(235, 36)
        Me.TextBox12.TabIndex = 31
        '
        'TextBox11
        '
        Me.TextBox11.Enabled = False
        Me.TextBox11.Location = New System.Drawing.Point(941, 194)
        Me.TextBox11.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(235, 36)
        Me.TextBox11.TabIndex = 36
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Snow
        Me.Label9.Location = New System.Drawing.Point(742, 125)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(172, 28)
        Me.Label9.TabIndex = 89
        Me.Label9.Text = "Cycle Time(CT)"
        '
        'r
        '
        Me.r.AutoSize = True
        Me.r.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.r.ForeColor = System.Drawing.Color.Snow
        Me.r.Location = New System.Drawing.Point(683, 159)
        Me.r.Name = "r"
        Me.r.Size = New System.Drawing.Size(231, 28)
        Me.r.TabIndex = 91
        Me.r.Text = "Production Time(PT)"
        '
        'ComboBox6
        '
        Me.ComboBox6.Enabled = False
        Me.ComboBox6.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Items.AddRange(New Object() {"/unit/Year", "/unit/Month", "/unit/Week", "/unit/Day"})
        Me.ComboBox6.Location = New System.Drawing.Point(843, 70)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(89, 28)
        Me.ComboBox6.TabIndex = 102
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.TextBox27)
        Me.GroupBox6.Controls.Add(Me.TextBox26)
        Me.GroupBox6.Controls.Add(Me.TextBox25)
        Me.GroupBox6.Controls.Add(Me.TextBox24)
        Me.GroupBox6.Controls.Add(Me.TextBox23)
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.TextBox8)
        Me.GroupBox6.Controls.Add(Me.TextBox6)
        Me.GroupBox6.Controls.Add(Me.TextBox5)
        Me.GroupBox6.Controls.Add(Me.TextBox4)
        Me.GroupBox6.Controls.Add(Me.TextBox3)
        Me.GroupBox6.Controls.Add(Me.TextBox2)
        Me.GroupBox6.Controls.Add(Me.Label6)
        Me.GroupBox6.Controls.Add(Me.Label5)
        Me.GroupBox6.Controls.Add(Me.Label4)
        Me.GroupBox6.Controls.Add(Me.Label3)
        Me.GroupBox6.Controls.Add(Me.Label2)
        Me.GroupBox6.Controls.Add(Me.Label1)
        Me.GroupBox6.Controls.Add(Me.TextBox1)
        Me.GroupBox6.Dock = System.Windows.Forms.DockStyle.Left
        Me.GroupBox6.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox6.Font = New System.Drawing.Font("Cambria", 18.0!)
        Me.GroupBox6.Location = New System.Drawing.Point(0, 1466)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(677, 0)
        Me.GroupBox6.TabIndex = 118
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Data"
        Me.GroupBox6.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.RadioButton1)
        Me.GroupBox3.Controls.Add(Me.RadioButton2)
        Me.GroupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox3.Font = New System.Drawing.Font("Cambria", 18.0!)
        Me.GroupBox3.Location = New System.Drawing.Point(230, 3)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(907, 97)
        Me.GroupBox3.TabIndex = 115
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Model"
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RadioButton2.Location = New System.Drawing.Point(500, 41)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(257, 33)
        Me.RadioButton2.TabIndex = 2
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Manufacturing model"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'ToolTip1
        '
        Me.ToolTip1.AutomaticDelay = 10
        Me.ToolTip1.AutoPopDelay = 20000
        Me.ToolTip1.InitialDelay = 0
        Me.ToolTip1.IsBalloon = True
        Me.ToolTip1.ReshowDelay = 2
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(9, 77)
        Me.TextBox28.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(123, 20)
        Me.TextBox28.TabIndex = 113
        Me.TextBox28.Visible = False
        '
        'TextBox22
        '
        Me.TextBox22.Enabled = False
        Me.TextBox22.Location = New System.Drawing.Point(379, 48)
        Me.TextBox22.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(276, 36)
        Me.TextBox22.TabIndex = 90
        Me.TextBox22.Visible = False
        '
        'ListBox6
        '
        Me.ListBox6.FormattingEnabled = True
        Me.ListBox6.Items.AddRange(New Object() {"1", "12", "48", "365"})
        Me.ListBox6.Location = New System.Drawing.Point(160, 48)
        Me.ListBox6.Name = "ListBox6"
        Me.ListBox6.Size = New System.Drawing.Size(68, 30)
        Me.ListBox6.TabIndex = 112
        Me.ListBox6.Visible = False
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RadioButton5.Location = New System.Drawing.Point(170, 32)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(114, 31)
        Me.RadioButton5.TabIndex = 7
        Me.RadioButton5.TabStop = True
        Me.RadioButton5.Text = "Variable"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'RadioButton6
        '
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RadioButton6.Location = New System.Drawing.Point(43, 31)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(118, 31)
        Me.RadioButton6.TabIndex = 6
        Me.RadioButton6.TabStop = True
        Me.RadioButton6.Text = "Constant"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton5)
        Me.GroupBox2.Controls.Add(Me.RadioButton6)
        Me.GroupBox2.Location = New System.Drawing.Point(17, 107)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(300, 78)
        Me.GroupBox2.TabIndex = 97
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Demand"
        '
        'ListBox5
        '
        Me.ListBox5.FormattingEnabled = True
        Me.ListBox5.Location = New System.Drawing.Point(83, 48)
        Me.ListBox5.Name = "ListBox5"
        Me.ListBox5.Size = New System.Drawing.Size(68, 30)
        Me.ListBox5.TabIndex = 107
        Me.ListBox5.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.RadioButton4)
        Me.GroupBox1.Controls.Add(Me.RadioButton3)
        Me.GroupBox1.Location = New System.Drawing.Point(390, 108)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(300, 77)
        Me.GroupBox1.TabIndex = 96
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Lead time"
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RadioButton4.Location = New System.Drawing.Point(170, 32)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(114, 31)
        Me.RadioButton4.TabIndex = 9
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Variable"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RadioButton3.Location = New System.Drawing.Point(43, 31)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(118, 31)
        Me.RadioButton3.TabIndex = 8
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "Constant"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'ListBox4
        '
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.Location = New System.Drawing.Point(9, 48)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(68, 30)
        Me.ListBox4.TabIndex = 106
        Me.ListBox4.Visible = False
        '
        'ListBox3
        '
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Location = New System.Drawing.Point(160, 12)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(67, 30)
        Me.ListBox3.TabIndex = 105
        Me.ListBox3.Visible = False
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(83, 12)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(68, 30)
        Me.ListBox2.TabIndex = 104
        Me.ListBox2.Visible = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(9, 12)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(68, 30)
        Me.ListBox1.TabIndex = 103
        Me.ListBox1.Visible = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.GroupBox2)
        Me.GroupBox4.Controls.Add(Me.GroupBox1)
        Me.GroupBox4.Controls.Add(Me.CheckBox1)
        Me.GroupBox4.Controls.Add(Me.CheckBox2)
        Me.GroupBox4.Controls.Add(Me.CheckBox3)
        Me.GroupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox4.Font = New System.Drawing.Font("Cambria", 16.0!)
        Me.GroupBox4.Location = New System.Drawing.Point(44, 106)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(726, 208)
        Me.GroupBox4.TabIndex = 114
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Criteria"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.CheckBox1.Location = New System.Drawing.Point(17, 42)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(204, 31)
        Me.CheckBox1.TabIndex = 3
        Me.CheckBox1.Text = "Shortage Allowed"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.CheckBox2.Location = New System.Drawing.Point(247, 42)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(216, 31)
        Me.CheckBox2.TabIndex = 4
        Me.CheckBox2.Text = "Lead Time allowed"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.CheckBox3.Location = New System.Drawing.Point(489, 42)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(209, 31)
        Me.CheckBox3.TabIndex = 5
        Me.CheckBox3.Text = "Discounts allowed"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'TextBox7
        '
        Me.TextBox7.Enabled = False
        Me.TextBox7.Location = New System.Drawing.Point(423, 159)
        Me.TextBox7.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(235, 36)
        Me.TextBox7.TabIndex = 32
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Snow
        Me.Label7.Location = New System.Drawing.Point(137, 159)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(259, 28)
        Me.Label7.TabIndex = 83
        Me.Label7.Text = "Maximum inventory(M)"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label29)
        Me.GroupBox8.Controls.Add(Me.Label28)
        Me.GroupBox8.Controls.Add(Me.Label27)
        Me.GroupBox8.Controls.Add(Me.TextBox31)
        Me.GroupBox8.Controls.Add(Me.TextBox30)
        Me.GroupBox8.Controls.Add(Me.TextBox29)
        Me.GroupBox8.Controls.Add(Me.Button3)
        Me.GroupBox8.Controls.Add(Me.Button2)
        Me.GroupBox8.Controls.Add(Me.Label21)
        Me.GroupBox8.Controls.Add(Me.ComboBox1)
        Me.GroupBox8.Controls.Add(Me.TextBox22)
        Me.GroupBox8.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox8.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox8.Font = New System.Drawing.Font("Cambria", 18.0!)
        Me.GroupBox8.Location = New System.Drawing.Point(0, 1355)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(1339, 111)
        Me.GroupBox8.TabIndex = 117
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Discount details"
        Me.GroupBox8.Visible = False
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Cambria", 10.0!)
        Me.Label29.Location = New System.Drawing.Point(550, 30)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(110, 16)
        Me.Label29.TabIndex = 100
        Me.Label29.Text = "Price or discount"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Cambria", 10.0!)
        Me.Label28.Location = New System.Drawing.Point(473, 30)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(22, 16)
        Me.Label28.TabIndex = 99
        Me.Label28.Text = "To"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Cambria", 10.0!)
        Me.Label27.Location = New System.Drawing.Point(368, 30)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(41, 16)
        Me.Label27.TabIndex = 98
        Me.Label27.Text = "From"
        '
        'TextBox31
        '
        Me.TextBox31.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.TextBox31.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.RecentlyUsedList
        Me.TextBox31.Enabled = False
        Me.TextBox31.Location = New System.Drawing.Point(539, 48)
        Me.TextBox31.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(135, 36)
        Me.TextBox31.TabIndex = 97
        '
        'TextBox30
        '
        Me.TextBox30.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.TextBox30.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.RecentlyUsedList
        Me.TextBox30.Enabled = False
        Me.TextBox30.Location = New System.Drawing.Point(444, 48)
        Me.TextBox30.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(92, 36)
        Me.TextBox30.TabIndex = 96
        '
        'TextBox29
        '
        Me.TextBox29.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.TextBox29.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.RecentlyUsedList
        Me.TextBox29.Enabled = False
        Me.TextBox29.Location = New System.Drawing.Point(344, 48)
        Me.TextBox29.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(96, 36)
        Me.TextBox29.TabIndex = 95
        '
        'Button3
        '
        Me.Button3.Enabled = False
        Me.Button3.Location = New System.Drawing.Point(1165, 48)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(121, 36)
        Me.Button3.TabIndex = 92
        Me.Button3.Text = "Arrange"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Enabled = False
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button2.Location = New System.Drawing.Point(683, 48)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(121, 36)
        Me.Button2.TabIndex = 91
        Me.Button2.Text = "--->"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(82, 48)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(216, 28)
        Me.Label21.TabIndex = 94
        Me.Label21.Text = "Discount levels(DC)"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(811, 48)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(348, 36)
        Me.ComboBox1.TabIndex = 93
        '
        'TextBox9
        '
        Me.TextBox9.Enabled = False
        Me.TextBox9.Location = New System.Drawing.Point(941, 125)
        Me.TextBox9.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(235, 36)
        Me.TextBox9.TabIndex = 34
        '
        'TextBox10
        '
        Me.TextBox10.Enabled = False
        Me.TextBox10.Location = New System.Drawing.Point(941, 159)
        Me.TextBox10.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(235, 36)
        Me.TextBox10.TabIndex = 35
        '
        'GroupBox7
        '
        Me.GroupBox7.AutoSize = True
        Me.GroupBox7.BackColor = System.Drawing.Color.DarkGreen
        Me.GroupBox7.Controls.Add(Me.Label54)
        Me.GroupBox7.Controls.Add(Me.Label24)
        Me.GroupBox7.Controls.Add(Me.TextBox67)
        Me.GroupBox7.Controls.Add(Me.Button9)
        Me.GroupBox7.Controls.Add(Me.Label53)
        Me.GroupBox7.Controls.Add(Me.TextBox62)
        Me.GroupBox7.Controls.Add(Me.Button5)
        Me.GroupBox7.Controls.Add(Me.Button4)
        Me.GroupBox7.Controls.Add(Me.Button1)
        Me.GroupBox7.Controls.Add(Me.Label36)
        Me.GroupBox7.Controls.Add(Me.TextBox36)
        Me.GroupBox7.Controls.Add(Me.Label20)
        Me.GroupBox7.Controls.Add(Me.TextBox21)
        Me.GroupBox7.Controls.Add(Me.Label19)
        Me.GroupBox7.Controls.Add(Me.Label16)
        Me.GroupBox7.Controls.Add(Me.Label17)
        Me.GroupBox7.Controls.Add(Me.Label18)
        Me.GroupBox7.Controls.Add(Me.TextBox20)
        Me.GroupBox7.Controls.Add(Me.TextBox19)
        Me.GroupBox7.Controls.Add(Me.TextBox18)
        Me.GroupBox7.Controls.Add(Me.TextBox17)
        Me.GroupBox7.Controls.Add(Me.Label15)
        Me.GroupBox7.Controls.Add(Me.TextBox16)
        Me.GroupBox7.Controls.Add(Me.TextBox14)
        Me.GroupBox7.Controls.Add(Me.TextBox15)
        Me.GroupBox7.Controls.Add(Me.Label13)
        Me.GroupBox7.Controls.Add(Me.Label14)
        Me.GroupBox7.Controls.Add(Me.ComboBox11)
        Me.GroupBox7.Controls.Add(Me.ComboBox10)
        Me.GroupBox7.Controls.Add(Me.ComboBox9)
        Me.GroupBox7.Controls.Add(Me.ComboBox8)
        Me.GroupBox7.Controls.Add(Me.ComboBox7)
        Me.GroupBox7.Controls.Add(Me.Label12)
        Me.GroupBox7.Controls.Add(Me.TextBox13)
        Me.GroupBox7.Controls.Add(Me.Label11)
        Me.GroupBox7.Controls.Add(Me.TextBox12)
        Me.GroupBox7.Controls.Add(Me.Label10)
        Me.GroupBox7.Controls.Add(Me.TextBox11)
        Me.GroupBox7.Controls.Add(Me.r)
        Me.GroupBox7.Controls.Add(Me.Label9)
        Me.GroupBox7.Controls.Add(Me.TextBox10)
        Me.GroupBox7.Controls.Add(Me.TextBox9)
        Me.GroupBox7.Controls.Add(Me.TextBox7)
        Me.GroupBox7.Controls.Add(Me.Label7)
        Me.GroupBox7.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox7.Font = New System.Drawing.Font("Cambria", 18.0!)
        Me.GroupBox7.ForeColor = System.Drawing.Color.Orange
        Me.GroupBox7.Location = New System.Drawing.Point(0, 822)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(1339, 533)
        Me.GroupBox7.TabIndex = 116
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Optimal values"
        '
        'Label54
        '
        Me.Label54.BackColor = System.Drawing.SystemColors.Control
        Me.Label54.Enabled = False
        Me.Label54.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label54.Location = New System.Drawing.Point(475, 55)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(283, 36)
        Me.Label54.TabIndex = 127
        Me.Label54.Text = "Net values"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Label54.Visible = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Cambria", 10.0!)
        Me.Label24.ForeColor = System.Drawing.Color.Snow
        Me.Label24.Location = New System.Drawing.Point(691, 473)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(236, 16)
        Me.Label24.TabIndex = 126
        Me.Label24.Text = """Constrained value:Actual/Achieved"""
        '
        'TextBox67
        '
        Me.TextBox67.Enabled = False
        Me.TextBox67.Location = New System.Drawing.Point(941, 459)
        Me.TextBox67.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(235, 36)
        Me.TextBox67.TabIndex = 125
        '
        'Button9
        '
        Me.Button9.CausesValidation = False
        Me.Button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button9.ForeColor = System.Drawing.Color.DarkGreen
        Me.Button9.Location = New System.Drawing.Point(178, 56)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(182, 37)
        Me.Button9.TabIndex = 28
        Me.Button9.Text = "Net values"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.Snow
        Me.Label53.Location = New System.Drawing.Point(577, 26)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(91, 28)
        Me.Label53.TabIndex = 124
        Me.Label53.Text = "Item no"
        '
        'TextBox62
        '
        Me.TextBox62.Location = New System.Drawing.Point(476, 55)
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.ReadOnly = True
        Me.TextBox62.Size = New System.Drawing.Size(283, 36)
        Me.TextBox62.TabIndex = 123
        Me.TextBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(764, 55)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(73, 37)
        Me.Button5.TabIndex = 30
        Me.Button5.Text = ">>"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(397, 55)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(73, 37)
        Me.Button4.TabIndex = 29
        Me.Button4.Text = "<<"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox5.Controls.Add(Me.Button8)
        Me.GroupBox5.Controls.Add(Me.GroupBox14)
        Me.GroupBox5.Controls.Add(Me.ListBox42)
        Me.GroupBox5.Controls.Add(Me.GroupBox11)
        Me.GroupBox5.Controls.Add(Me.GroupBox10)
        Me.GroupBox5.Controls.Add(Me.CheckBox4)
        Me.GroupBox5.Controls.Add(Me.ComboBox5)
        Me.GroupBox5.Controls.Add(Me.ComboBox3)
        Me.GroupBox5.Controls.Add(Me.ComboBox6)
        Me.GroupBox5.Controls.Add(Me.ComboBox4)
        Me.GroupBox5.Controls.Add(Me.CheckBox5)
        Me.GroupBox5.Controls.Add(Me.ComboBox2)
        Me.GroupBox5.Controls.Add(Me.Label45)
        Me.GroupBox5.Controls.Add(Me.Label44)
        Me.GroupBox5.Controls.Add(Me.Label43)
        Me.GroupBox5.Controls.Add(Me.Label42)
        Me.GroupBox5.Controls.Add(Me.Label40)
        Me.GroupBox5.Controls.Add(Me.Label39)
        Me.GroupBox5.Controls.Add(Me.Label38)
        Me.GroupBox5.Controls.Add(Me.TextBox37)
        Me.GroupBox5.Controls.Add(Me.ListBox55)
        Me.GroupBox5.Controls.Add(Me.TextBox61)
        Me.GroupBox5.Controls.Add(Me.TextBox60)
        Me.GroupBox5.Controls.Add(Me.TextBox59)
        Me.GroupBox5.Controls.Add(Me.TextBox58)
        Me.GroupBox5.Controls.Add(Me.TextBox57)
        Me.GroupBox5.Controls.Add(Me.TextBox56)
        Me.GroupBox5.Controls.Add(Me.TextBox55)
        Me.GroupBox5.Controls.Add(Me.TextBox54)
        Me.GroupBox5.Controls.Add(Me.TextBox53)
        Me.GroupBox5.Controls.Add(Me.TextBox52)
        Me.GroupBox5.Controls.Add(Me.TextBox51)
        Me.GroupBox5.Controls.Add(Me.TextBox50)
        Me.GroupBox5.Controls.Add(Me.TextBox43)
        Me.GroupBox5.Controls.Add(Me.TextBox42)
        Me.GroupBox5.Controls.Add(Me.TextBox41)
        Me.GroupBox5.Controls.Add(Me.TextBox40)
        Me.GroupBox5.Controls.Add(Me.TextBox38)
        Me.GroupBox5.Controls.Add(Me.ListBox31)
        Me.GroupBox5.Controls.Add(Me.ListBox32)
        Me.GroupBox5.Controls.Add(Me.ListBox33)
        Me.GroupBox5.Controls.Add(Me.ListBox34)
        Me.GroupBox5.Controls.Add(Me.ListBox35)
        Me.GroupBox5.Controls.Add(Me.ListBox36)
        Me.GroupBox5.Controls.Add(Me.ListBox37)
        Me.GroupBox5.Controls.Add(Me.ListBox38)
        Me.GroupBox5.Controls.Add(Me.ListBox39)
        Me.GroupBox5.Controls.Add(Me.ListBox40)
        Me.GroupBox5.Controls.Add(Me.ListBox41)
        Me.GroupBox5.Controls.Add(Me.ListBox43)
        Me.GroupBox5.Controls.Add(Me.ListBox44)
        Me.GroupBox5.Controls.Add(Me.ListBox45)
        Me.GroupBox5.Controls.Add(Me.ListBox46)
        Me.GroupBox5.Controls.Add(Me.ListBox47)
        Me.GroupBox5.Controls.Add(Me.ListBox48)
        Me.GroupBox5.Controls.Add(Me.ListBox49)
        Me.GroupBox5.Controls.Add(Me.ListBox50)
        Me.GroupBox5.Controls.Add(Me.ListBox51)
        Me.GroupBox5.Controls.Add(Me.ListBox52)
        Me.GroupBox5.Controls.Add(Me.ListBox53)
        Me.GroupBox5.Controls.Add(Me.ListBox54)
        Me.GroupBox5.Controls.Add(Me.ListBox19)
        Me.GroupBox5.Controls.Add(Me.ListBox20)
        Me.GroupBox5.Controls.Add(Me.ListBox21)
        Me.GroupBox5.Controls.Add(Me.ListBox22)
        Me.GroupBox5.Controls.Add(Me.ListBox23)
        Me.GroupBox5.Controls.Add(Me.ListBox24)
        Me.GroupBox5.Controls.Add(Me.ListBox25)
        Me.GroupBox5.Controls.Add(Me.ListBox26)
        Me.GroupBox5.Controls.Add(Me.ListBox27)
        Me.GroupBox5.Controls.Add(Me.ListBox28)
        Me.GroupBox5.Controls.Add(Me.ListBox29)
        Me.GroupBox5.Controls.Add(Me.ListBox30)
        Me.GroupBox5.Controls.Add(Me.ListBox13)
        Me.GroupBox5.Controls.Add(Me.ListBox11)
        Me.GroupBox5.Controls.Add(Me.ListBox12)
        Me.GroupBox5.Controls.Add(Me.ListBox9)
        Me.GroupBox5.Controls.Add(Me.ListBox10)
        Me.GroupBox5.Controls.Add(Me.ListBox8)
        Me.GroupBox5.Controls.Add(Me.ListBox7)
        Me.GroupBox5.Controls.Add(Me.Label41)
        Me.GroupBox5.Controls.Add(Me.TextBox39)
        Me.GroupBox5.Controls.Add(Me.Label25)
        Me.GroupBox5.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox5.Font = New System.Drawing.Font("Cambria", 18.0!)
        Me.GroupBox5.Location = New System.Drawing.Point(0, 329)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(1339, 493)
        Me.GroupBox5.TabIndex = 98
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Data"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(44, 425)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(1261, 52)
        Me.Button8.TabIndex = 26
        Me.Button8.Text = "Add item"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.Label22)
        Me.GroupBox14.Controls.Add(Me.TextBox63)
        Me.GroupBox14.Controls.Add(Me.ListBox18)
        Me.GroupBox14.Enabled = False
        Me.GroupBox14.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.GroupBox14.Location = New System.Drawing.Point(1150, 214)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(155, 205)
        Me.GroupBox14.TabIndex = 145
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Constraint"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.Label22.Location = New System.Drawing.Point(29, 41)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(95, 21)
        Me.Label22.TabIndex = 144
        Me.Label22.Text = "Space/unit"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox63
        '
        Me.TextBox63.Location = New System.Drawing.Point(14, 64)
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Size = New System.Drawing.Size(121, 28)
        Me.TextBox63.TabIndex = 143
        '
        'ListBox18
        '
        Me.ListBox18.Enabled = False
        Me.ListBox18.FormattingEnabled = True
        Me.ListBox18.ItemHeight = 20
        Me.ListBox18.Location = New System.Drawing.Point(12, 106)
        Me.ListBox18.Name = "ListBox18"
        Me.ListBox18.Size = New System.Drawing.Size(123, 84)
        Me.ListBox18.TabIndex = 6
        '
        'ListBox42
        '
        Me.ListBox42.FormattingEnabled = True
        Me.ListBox42.ItemHeight = 28
        Me.ListBox42.Location = New System.Drawing.Point(620, 588)
        Me.ListBox42.Name = "ListBox42"
        Me.ListBox42.Size = New System.Drawing.Size(58, 4)
        Me.ListBox42.TabIndex = 36
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Label50)
        Me.GroupBox11.Controls.Add(Me.ComboBox13)
        Me.GroupBox11.Controls.Add(Me.Label49)
        Me.GroupBox11.Controls.Add(Me.ComboBox12)
        Me.GroupBox11.Controls.Add(Me.Label47)
        Me.GroupBox11.Controls.Add(Me.Label26)
        Me.GroupBox11.Controls.Add(Me.Label46)
        Me.GroupBox11.Controls.Add(Me.TextBox46)
        Me.GroupBox11.Controls.Add(Me.TextBox45)
        Me.GroupBox11.Controls.Add(Me.TextBox44)
        Me.GroupBox11.Controls.Add(Me.ListBox14)
        Me.GroupBox11.Controls.Add(Me.ListBox15)
        Me.GroupBox11.Controls.Add(Me.ListBox16)
        Me.GroupBox11.Enabled = False
        Me.GroupBox11.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.GroupBox11.Location = New System.Drawing.Point(552, 214)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(570, 206)
        Me.GroupBox11.TabIndex = 142
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Safety stock data"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label50.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(444, 32)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(44, 28)
        Me.Label50.TabIndex = 134
        Me.Label50.Text = "σ L"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label49.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(261, 32)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(44, 28)
        Me.Label49.TabIndex = 133
        Me.Label49.Text = "σ d"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.Label47.Location = New System.Drawing.Point(311, 41)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(0, 21)
        Me.Label47.TabIndex = 132
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label47.Visible = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.Label26.Location = New System.Drawing.Point(319, 39)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(0, 21)
        Me.Label26.TabIndex = 131
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label26.Visible = False
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.Label46.Location = New System.Drawing.Point(23, 34)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(161, 21)
        Me.Label46.TabIndex = 130
        Me.Label46.Text = "Service Level(in %)"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox46
        '
        Me.TextBox46.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox46.Location = New System.Drawing.Point(371, 64)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(96, 28)
        Me.TextBox46.TabIndex = 25
        '
        'TextBox45
        '
        Me.TextBox45.Enabled = False
        Me.TextBox45.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox45.Location = New System.Drawing.Point(184, 64)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(96, 28)
        Me.TextBox45.TabIndex = 24
        '
        'TextBox44
        '
        Me.TextBox44.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox44.Location = New System.Drawing.Point(26, 64)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(149, 28)
        Me.TextBox44.TabIndex = 23
        '
        'ListBox14
        '
        Me.ListBox14.Enabled = False
        Me.ListBox14.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox14.FormattingEnabled = True
        Me.ListBox14.ItemHeight = 20
        Me.ListBox14.Location = New System.Drawing.Point(26, 106)
        Me.ListBox14.Name = "ListBox14"
        Me.ListBox14.Size = New System.Drawing.Size(149, 84)
        Me.ListBox14.TabIndex = 10
        '
        'ListBox15
        '
        Me.ListBox15.Enabled = False
        Me.ListBox15.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox15.FormattingEnabled = True
        Me.ListBox15.ItemHeight = 20
        Me.ListBox15.Location = New System.Drawing.Point(184, 106)
        Me.ListBox15.Name = "ListBox15"
        Me.ListBox15.Size = New System.Drawing.Size(181, 84)
        Me.ListBox15.TabIndex = 9
        '
        'ListBox16
        '
        Me.ListBox16.Enabled = False
        Me.ListBox16.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox16.FormattingEnabled = True
        Me.ListBox16.ItemHeight = 20
        Me.ListBox16.Location = New System.Drawing.Point(371, 106)
        Me.ListBox16.Name = "ListBox16"
        Me.ListBox16.Size = New System.Drawing.Size(177, 84)
        Me.ListBox16.TabIndex = 8
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Label48)
        Me.GroupBox10.Controls.Add(Me.Label51)
        Me.GroupBox10.Controls.Add(Me.Label52)
        Me.GroupBox10.Controls.Add(Me.Button7)
        Me.GroupBox10.Controls.Add(Me.ComboBox14)
        Me.GroupBox10.Controls.Add(Me.TextBox49)
        Me.GroupBox10.Controls.Add(Me.TextBox48)
        Me.GroupBox10.Controls.Add(Me.TextBox47)
        Me.GroupBox10.Controls.Add(Me.ListBox17)
        Me.GroupBox10.Enabled = False
        Me.GroupBox10.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.GroupBox10.Location = New System.Drawing.Point(44, 213)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(483, 206)
        Me.GroupBox10.TabIndex = 141
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Discount details"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Cambria", 10.0!)
        Me.Label48.Location = New System.Drawing.Point(183, 43)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(122, 16)
        Me.Label48.TabIndex = 140
        Me.Label48.Text = "Price or discount%"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Cambria", 10.0!)
        Me.Label51.Location = New System.Drawing.Point(129, 43)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(22, 16)
        Me.Label51.TabIndex = 139
        Me.Label51.Text = "To"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Cambria", 10.0!)
        Me.Label52.Location = New System.Drawing.Point(51, 43)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(41, 16)
        Me.Label52.TabIndex = 138
        Me.Label52.Text = "From"
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(27, 106)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(275, 42)
        Me.Button7.TabIndex = 22
        Me.Button7.Text = "▼"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'ComboBox14
        '
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Location = New System.Drawing.Point(27, 154)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(275, 28)
        Me.ComboBox14.TabIndex = 135
        '
        'TextBox49
        '
        Me.TextBox49.Location = New System.Drawing.Point(183, 64)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(119, 28)
        Me.TextBox49.TabIndex = 21
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(105, 64)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(72, 28)
        Me.TextBox48.TabIndex = 20
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(27, 64)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(72, 28)
        Me.TextBox47.TabIndex = 19
        '
        'ListBox17
        '
        Me.ListBox17.Enabled = False
        Me.ListBox17.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox17.FormattingEnabled = True
        Me.ListBox17.ItemHeight = 20
        Me.ListBox17.Location = New System.Drawing.Point(334, 58)
        Me.ListBox17.Name = "ListBox17"
        Me.ListBox17.Size = New System.Drawing.Size(117, 124)
        Me.ListBox17.TabIndex = 7
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.Label45.Location = New System.Drawing.Point(1162, 43)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(116, 21)
        Me.Label45.TabIndex = 129
        Me.Label45.Text = "Lead Time(L)"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Cambria", 12.0!)
        Me.Label44.Location = New System.Drawing.Point(956, 45)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(142, 19)
        Me.Label44.TabIndex = 128
        Me.Label44.Text = "Production Rate(P)"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Cambria", 12.0!)
        Me.Label43.Location = New System.Drawing.Point(776, 45)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(125, 19)
        Me.Label43.TabIndex = 127
        Me.Label43.Text = "Shortage Cost(S)"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Cambria", 12.0!)
        Me.Label42.Location = New System.Drawing.Point(607, 45)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(106, 19)
        Me.Label42.TabIndex = 126
        Me.Label42.Text = "Order Cost(O)"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Cambria", 12.0!)
        Me.Label40.Location = New System.Drawing.Point(43, 45)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(62, 19)
        Me.Label40.TabIndex = 124
        Me.Label40.Text = "Item no"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Cambria", 12.0!)
        Me.Label39.Location = New System.Drawing.Point(293, 45)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(91, 19)
        Me.Label39.TabIndex = 123
        Me.Label39.Text = "Item Cost(I)"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Cambria", 12.0!)
        Me.Label38.Location = New System.Drawing.Point(139, 45)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(90, 19)
        Me.Label38.TabIndex = 122
        Me.Label38.Text = "Demand(D)"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox37
        '
        Me.TextBox37.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox37.Location = New System.Drawing.Point(99, 70)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(83, 28)
        Me.TextBox37.TabIndex = 10
        '
        'ListBox55
        '
        Me.ListBox55.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox55.FormattingEnabled = True
        Me.ListBox55.ItemHeight = 20
        Me.ListBox55.Location = New System.Drawing.Point(44, 122)
        Me.ListBox55.Name = "ListBox55"
        Me.ListBox55.Size = New System.Drawing.Size(53, 64)
        Me.ListBox55.TabIndex = 74
        '
        'TextBox61
        '
        Me.TextBox61.Location = New System.Drawing.Point(984, 516)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(63, 36)
        Me.TextBox61.TabIndex = 72
        '
        'TextBox60
        '
        Me.TextBox60.Location = New System.Drawing.Point(924, 516)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(63, 36)
        Me.TextBox60.TabIndex = 71
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(863, 516)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(63, 36)
        Me.TextBox59.TabIndex = 70
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(804, 516)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(63, 36)
        Me.TextBox58.TabIndex = 69
        '
        'TextBox57
        '
        Me.TextBox57.Location = New System.Drawing.Point(741, 516)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(63, 36)
        Me.TextBox57.TabIndex = 68
        '
        'TextBox56
        '
        Me.TextBox56.Location = New System.Drawing.Point(683, 516)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(63, 36)
        Me.TextBox56.TabIndex = 67
        '
        'TextBox55
        '
        Me.TextBox55.Location = New System.Drawing.Point(626, 516)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(63, 36)
        Me.TextBox55.TabIndex = 66
        '
        'TextBox54
        '
        Me.TextBox54.Location = New System.Drawing.Point(568, 516)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(63, 36)
        Me.TextBox54.TabIndex = 65
        '
        'TextBox53
        '
        Me.TextBox53.Location = New System.Drawing.Point(508, 516)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(63, 36)
        Me.TextBox53.TabIndex = 64
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(446, 516)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(63, 36)
        Me.TextBox52.TabIndex = 63
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(383, 516)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(63, 36)
        Me.TextBox51.TabIndex = 62
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(320, 516)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(63, 36)
        Me.TextBox50.TabIndex = 61
        '
        'TextBox43
        '
        Me.TextBox43.Enabled = False
        Me.TextBox43.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox43.Location = New System.Drawing.Point(1125, 70)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(90, 28)
        Me.TextBox43.TabIndex = 18
        '
        'TextBox42
        '
        Me.TextBox42.Enabled = False
        Me.TextBox42.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox42.Location = New System.Drawing.Point(935, 70)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(93, 28)
        Me.TextBox42.TabIndex = 17
        '
        'TextBox41
        '
        Me.TextBox41.Enabled = False
        Me.TextBox41.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox41.Location = New System.Drawing.Point(713, 70)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(131, 28)
        Me.TextBox41.TabIndex = 15
        '
        'TextBox40
        '
        Me.TextBox40.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox40.Location = New System.Drawing.Point(610, 70)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(100, 28)
        Me.TextBox40.TabIndex = 14
        '
        'TextBox38
        '
        Me.TextBox38.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox38.Location = New System.Drawing.Point(286, 70)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(100, 28)
        Me.TextBox38.TabIndex = 11
        '
        'ListBox31
        '
        Me.ListBox31.FormattingEnabled = True
        Me.ListBox31.ItemHeight = 28
        Me.ListBox31.Location = New System.Drawing.Point(3, 588)
        Me.ListBox31.Name = "ListBox31"
        Me.ListBox31.Size = New System.Drawing.Size(58, 4)
        Me.ListBox31.TabIndex = 47
        '
        'ListBox32
        '
        Me.ListBox32.FormattingEnabled = True
        Me.ListBox32.ItemHeight = 28
        Me.ListBox32.Location = New System.Drawing.Point(60, 588)
        Me.ListBox32.Name = "ListBox32"
        Me.ListBox32.Size = New System.Drawing.Size(58, 4)
        Me.ListBox32.TabIndex = 46
        '
        'ListBox33
        '
        Me.ListBox33.FormattingEnabled = True
        Me.ListBox33.ItemHeight = 28
        Me.ListBox33.Location = New System.Drawing.Point(117, 588)
        Me.ListBox33.Name = "ListBox33"
        Me.ListBox33.Size = New System.Drawing.Size(58, 4)
        Me.ListBox33.TabIndex = 45
        '
        'ListBox34
        '
        Me.ListBox34.FormattingEnabled = True
        Me.ListBox34.ItemHeight = 28
        Me.ListBox34.Location = New System.Drawing.Point(175, 588)
        Me.ListBox34.Name = "ListBox34"
        Me.ListBox34.Size = New System.Drawing.Size(58, 4)
        Me.ListBox34.TabIndex = 44
        '
        'ListBox35
        '
        Me.ListBox35.FormattingEnabled = True
        Me.ListBox35.ItemHeight = 28
        Me.ListBox35.Location = New System.Drawing.Point(230, 588)
        Me.ListBox35.Name = "ListBox35"
        Me.ListBox35.Size = New System.Drawing.Size(58, 4)
        Me.ListBox35.TabIndex = 43
        '
        'ListBox36
        '
        Me.ListBox36.FormattingEnabled = True
        Me.ListBox36.ItemHeight = 28
        Me.ListBox36.Location = New System.Drawing.Point(287, 588)
        Me.ListBox36.Name = "ListBox36"
        Me.ListBox36.Size = New System.Drawing.Size(58, 4)
        Me.ListBox36.TabIndex = 42
        '
        'ListBox37
        '
        Me.ListBox37.FormattingEnabled = True
        Me.ListBox37.ItemHeight = 28
        Me.ListBox37.Location = New System.Drawing.Point(344, 588)
        Me.ListBox37.Name = "ListBox37"
        Me.ListBox37.Size = New System.Drawing.Size(58, 4)
        Me.ListBox37.TabIndex = 41
        '
        'ListBox38
        '
        Me.ListBox38.FormattingEnabled = True
        Me.ListBox38.ItemHeight = 28
        Me.ListBox38.Location = New System.Drawing.Point(395, 588)
        Me.ListBox38.Name = "ListBox38"
        Me.ListBox38.Size = New System.Drawing.Size(58, 4)
        Me.ListBox38.TabIndex = 40
        '
        'ListBox39
        '
        Me.ListBox39.FormattingEnabled = True
        Me.ListBox39.ItemHeight = 28
        Me.ListBox39.Location = New System.Drawing.Point(452, 588)
        Me.ListBox39.Name = "ListBox39"
        Me.ListBox39.Size = New System.Drawing.Size(58, 4)
        Me.ListBox39.TabIndex = 39
        '
        'ListBox40
        '
        Me.ListBox40.FormattingEnabled = True
        Me.ListBox40.ItemHeight = 28
        Me.ListBox40.Location = New System.Drawing.Point(509, 588)
        Me.ListBox40.Name = "ListBox40"
        Me.ListBox40.Size = New System.Drawing.Size(58, 4)
        Me.ListBox40.TabIndex = 38
        '
        'ListBox41
        '
        Me.ListBox41.FormattingEnabled = True
        Me.ListBox41.ItemHeight = 28
        Me.ListBox41.Location = New System.Drawing.Point(566, 588)
        Me.ListBox41.Name = "ListBox41"
        Me.ListBox41.Size = New System.Drawing.Size(58, 4)
        Me.ListBox41.TabIndex = 37
        '
        'ListBox43
        '
        Me.ListBox43.FormattingEnabled = True
        Me.ListBox43.ItemHeight = 28
        Me.ListBox43.Location = New System.Drawing.Point(680, 588)
        Me.ListBox43.Name = "ListBox43"
        Me.ListBox43.Size = New System.Drawing.Size(58, 4)
        Me.ListBox43.TabIndex = 35
        '
        'ListBox44
        '
        Me.ListBox44.FormattingEnabled = True
        Me.ListBox44.ItemHeight = 28
        Me.ListBox44.Location = New System.Drawing.Point(737, 588)
        Me.ListBox44.Name = "ListBox44"
        Me.ListBox44.Size = New System.Drawing.Size(58, 4)
        Me.ListBox44.TabIndex = 34
        '
        'ListBox45
        '
        Me.ListBox45.FormattingEnabled = True
        Me.ListBox45.ItemHeight = 28
        Me.ListBox45.Location = New System.Drawing.Point(795, 588)
        Me.ListBox45.Name = "ListBox45"
        Me.ListBox45.Size = New System.Drawing.Size(58, 4)
        Me.ListBox45.TabIndex = 33
        '
        'ListBox46
        '
        Me.ListBox46.FormattingEnabled = True
        Me.ListBox46.ItemHeight = 28
        Me.ListBox46.Location = New System.Drawing.Point(853, 588)
        Me.ListBox46.Name = "ListBox46"
        Me.ListBox46.Size = New System.Drawing.Size(58, 4)
        Me.ListBox46.TabIndex = 32
        '
        'ListBox47
        '
        Me.ListBox47.FormattingEnabled = True
        Me.ListBox47.ItemHeight = 28
        Me.ListBox47.Location = New System.Drawing.Point(906, 588)
        Me.ListBox47.Name = "ListBox47"
        Me.ListBox47.Size = New System.Drawing.Size(58, 4)
        Me.ListBox47.TabIndex = 31
        '
        'ListBox48
        '
        Me.ListBox48.FormattingEnabled = True
        Me.ListBox48.ItemHeight = 28
        Me.ListBox48.Location = New System.Drawing.Point(963, 588)
        Me.ListBox48.Name = "ListBox48"
        Me.ListBox48.Size = New System.Drawing.Size(58, 4)
        Me.ListBox48.TabIndex = 30
        '
        'ListBox49
        '
        Me.ListBox49.FormattingEnabled = True
        Me.ListBox49.ItemHeight = 28
        Me.ListBox49.Location = New System.Drawing.Point(1013, 588)
        Me.ListBox49.Name = "ListBox49"
        Me.ListBox49.Size = New System.Drawing.Size(58, 4)
        Me.ListBox49.TabIndex = 29
        '
        'ListBox50
        '
        Me.ListBox50.FormattingEnabled = True
        Me.ListBox50.ItemHeight = 28
        Me.ListBox50.Location = New System.Drawing.Point(1071, 588)
        Me.ListBox50.Name = "ListBox50"
        Me.ListBox50.Size = New System.Drawing.Size(58, 4)
        Me.ListBox50.TabIndex = 28
        '
        'ListBox51
        '
        Me.ListBox51.FormattingEnabled = True
        Me.ListBox51.ItemHeight = 28
        Me.ListBox51.Location = New System.Drawing.Point(1115, 588)
        Me.ListBox51.Name = "ListBox51"
        Me.ListBox51.Size = New System.Drawing.Size(58, 4)
        Me.ListBox51.TabIndex = 27
        '
        'ListBox52
        '
        Me.ListBox52.FormattingEnabled = True
        Me.ListBox52.ItemHeight = 28
        Me.ListBox52.Location = New System.Drawing.Point(1165, 588)
        Me.ListBox52.Name = "ListBox52"
        Me.ListBox52.Size = New System.Drawing.Size(58, 4)
        Me.ListBox52.TabIndex = 26
        '
        'ListBox53
        '
        Me.ListBox53.FormattingEnabled = True
        Me.ListBox53.ItemHeight = 28
        Me.ListBox53.Location = New System.Drawing.Point(1180, 588)
        Me.ListBox53.Name = "ListBox53"
        Me.ListBox53.Size = New System.Drawing.Size(58, 4)
        Me.ListBox53.TabIndex = 25
        '
        'ListBox54
        '
        Me.ListBox54.FormattingEnabled = True
        Me.ListBox54.ItemHeight = 28
        Me.ListBox54.Location = New System.Drawing.Point(1237, 588)
        Me.ListBox54.Name = "ListBox54"
        Me.ListBox54.Size = New System.Drawing.Size(58, 4)
        Me.ListBox54.TabIndex = 24
        '
        'ListBox19
        '
        Me.ListBox19.FormattingEnabled = True
        Me.ListBox19.ItemHeight = 28
        Me.ListBox19.Location = New System.Drawing.Point(266, 566)
        Me.ListBox19.Name = "ListBox19"
        Me.ListBox19.Size = New System.Drawing.Size(58, 4)
        Me.ListBox19.TabIndex = 23
        '
        'ListBox20
        '
        Me.ListBox20.FormattingEnabled = True
        Me.ListBox20.ItemHeight = 28
        Me.ListBox20.Location = New System.Drawing.Point(329, 567)
        Me.ListBox20.Name = "ListBox20"
        Me.ListBox20.Size = New System.Drawing.Size(58, 4)
        Me.ListBox20.TabIndex = 22
        '
        'ListBox21
        '
        Me.ListBox21.FormattingEnabled = True
        Me.ListBox21.ItemHeight = 28
        Me.ListBox21.Location = New System.Drawing.Point(392, 568)
        Me.ListBox21.Name = "ListBox21"
        Me.ListBox21.Size = New System.Drawing.Size(58, 4)
        Me.ListBox21.TabIndex = 21
        '
        'ListBox22
        '
        Me.ListBox22.FormattingEnabled = True
        Me.ListBox22.ItemHeight = 28
        Me.ListBox22.Location = New System.Drawing.Point(456, 567)
        Me.ListBox22.Name = "ListBox22"
        Me.ListBox22.Size = New System.Drawing.Size(58, 4)
        Me.ListBox22.TabIndex = 20
        '
        'ListBox23
        '
        Me.ListBox23.FormattingEnabled = True
        Me.ListBox23.ItemHeight = 28
        Me.ListBox23.Location = New System.Drawing.Point(515, 566)
        Me.ListBox23.Name = "ListBox23"
        Me.ListBox23.Size = New System.Drawing.Size(58, 4)
        Me.ListBox23.TabIndex = 19
        '
        'ListBox24
        '
        Me.ListBox24.FormattingEnabled = True
        Me.ListBox24.ItemHeight = 28
        Me.ListBox24.Location = New System.Drawing.Point(579, 566)
        Me.ListBox24.Name = "ListBox24"
        Me.ListBox24.Size = New System.Drawing.Size(58, 4)
        Me.ListBox24.TabIndex = 18
        '
        'ListBox25
        '
        Me.ListBox25.FormattingEnabled = True
        Me.ListBox25.ItemHeight = 28
        Me.ListBox25.Location = New System.Drawing.Point(638, 566)
        Me.ListBox25.Name = "ListBox25"
        Me.ListBox25.Size = New System.Drawing.Size(58, 4)
        Me.ListBox25.TabIndex = 17
        '
        'ListBox26
        '
        Me.ListBox26.FormattingEnabled = True
        Me.ListBox26.ItemHeight = 28
        Me.ListBox26.Location = New System.Drawing.Point(702, 566)
        Me.ListBox26.Name = "ListBox26"
        Me.ListBox26.Size = New System.Drawing.Size(58, 4)
        Me.ListBox26.TabIndex = 16
        '
        'ListBox27
        '
        Me.ListBox27.FormattingEnabled = True
        Me.ListBox27.ItemHeight = 28
        Me.ListBox27.Location = New System.Drawing.Point(759, 567)
        Me.ListBox27.Name = "ListBox27"
        Me.ListBox27.Size = New System.Drawing.Size(58, 4)
        Me.ListBox27.TabIndex = 15
        '
        'ListBox28
        '
        Me.ListBox28.FormattingEnabled = True
        Me.ListBox28.ItemHeight = 28
        Me.ListBox28.Location = New System.Drawing.Point(817, 568)
        Me.ListBox28.Name = "ListBox28"
        Me.ListBox28.Size = New System.Drawing.Size(58, 4)
        Me.ListBox28.TabIndex = 14
        '
        'ListBox29
        '
        Me.ListBox29.FormattingEnabled = True
        Me.ListBox29.ItemHeight = 28
        Me.ListBox29.Location = New System.Drawing.Point(875, 568)
        Me.ListBox29.Name = "ListBox29"
        Me.ListBox29.Size = New System.Drawing.Size(58, 4)
        Me.ListBox29.TabIndex = 13
        '
        'ListBox30
        '
        Me.ListBox30.FormattingEnabled = True
        Me.ListBox30.ItemHeight = 28
        Me.ListBox30.Location = New System.Drawing.Point(931, 568)
        Me.ListBox30.Name = "ListBox30"
        Me.ListBox30.Size = New System.Drawing.Size(58, 4)
        Me.ListBox30.TabIndex = 12
        '
        'ListBox13
        '
        Me.ListBox13.Cursor = System.Windows.Forms.Cursors.No
        Me.ListBox13.Enabled = False
        Me.ListBox13.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox13.FormattingEnabled = True
        Me.ListBox13.ItemHeight = 20
        Me.ListBox13.Location = New System.Drawing.Point(1125, 122)
        Me.ListBox13.Name = "ListBox13"
        Me.ListBox13.Size = New System.Drawing.Size(180, 64)
        Me.ListBox13.TabIndex = 11
        '
        'ListBox11
        '
        Me.ListBox11.Cursor = System.Windows.Forms.Cursors.No
        Me.ListBox11.Enabled = False
        Me.ListBox11.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox11.FormattingEnabled = True
        Me.ListBox11.ItemHeight = 20
        Me.ListBox11.Location = New System.Drawing.Point(713, 122)
        Me.ListBox11.Name = "ListBox11"
        Me.ListBox11.Size = New System.Drawing.Size(219, 64)
        Me.ListBox11.TabIndex = 5
        '
        'ListBox12
        '
        Me.ListBox12.Cursor = System.Windows.Forms.Cursors.No
        Me.ListBox12.Enabled = False
        Me.ListBox12.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox12.FormattingEnabled = True
        Me.ListBox12.ItemHeight = 20
        Me.ListBox12.Location = New System.Drawing.Point(935, 122)
        Me.ListBox12.Name = "ListBox12"
        Me.ListBox12.Size = New System.Drawing.Size(187, 64)
        Me.ListBox12.TabIndex = 4
        '
        'ListBox9
        '
        Me.ListBox9.Cursor = System.Windows.Forms.Cursors.No
        Me.ListBox9.Enabled = False
        Me.ListBox9.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox9.FormattingEnabled = True
        Me.ListBox9.ItemHeight = 20
        Me.ListBox9.Location = New System.Drawing.Point(389, 122)
        Me.ListBox9.Name = "ListBox9"
        Me.ListBox9.Size = New System.Drawing.Size(218, 64)
        Me.ListBox9.TabIndex = 3
        '
        'ListBox10
        '
        Me.ListBox10.Cursor = System.Windows.Forms.Cursors.No
        Me.ListBox10.Enabled = False
        Me.ListBox10.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox10.FormattingEnabled = True
        Me.ListBox10.ItemHeight = 20
        Me.ListBox10.Location = New System.Drawing.Point(610, 122)
        Me.ListBox10.Name = "ListBox10"
        Me.ListBox10.Size = New System.Drawing.Size(100, 64)
        Me.ListBox10.TabIndex = 2
        '
        'ListBox8
        '
        Me.ListBox8.Cursor = System.Windows.Forms.Cursors.No
        Me.ListBox8.Enabled = False
        Me.ListBox8.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox8.FormattingEnabled = True
        Me.ListBox8.ItemHeight = 20
        Me.ListBox8.Location = New System.Drawing.Point(286, 122)
        Me.ListBox8.Name = "ListBox8"
        Me.ListBox8.Size = New System.Drawing.Size(100, 64)
        Me.ListBox8.TabIndex = 1
        '
        'ListBox7
        '
        Me.ListBox7.Cursor = System.Windows.Forms.Cursors.No
        Me.ListBox7.Enabled = False
        Me.ListBox7.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.ListBox7.FormattingEnabled = True
        Me.ListBox7.ItemHeight = 20
        Me.ListBox7.Location = New System.Drawing.Point(99, 122)
        Me.ListBox7.Name = "ListBox7"
        Me.ListBox7.Size = New System.Drawing.Size(183, 64)
        Me.ListBox7.TabIndex = 0
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Cambria", 12.0!)
        Me.Label41.Location = New System.Drawing.Point(442, 45)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(120, 19)
        Me.Label41.TabIndex = 125
        Me.Label41.Text = "Holding Cost(H)"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox39
        '
        Me.TextBox39.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.TextBox39.Location = New System.Drawing.Point(389, 70)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(126, 28)
        Me.TextBox39.TabIndex = 12
        '
        'Label25
        '
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label25.Font = New System.Drawing.Font("Cambria", 13.0!)
        Me.Label25.Location = New System.Drawing.Point(44, 70)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(53, 28)
        Me.Label25.TabIndex = 73
        Me.Label25.Text = "1"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(1172, 32)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(73, 57)
        Me.Button6.TabIndex = 122
        Me.Button6.Text = ">>"
        Me.Button6.UseVisualStyleBackColor = True
        Me.Button6.Visible = False
        '
        'GroupBox12
        '
        Me.GroupBox12.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox12.Controls.Add(Me.GroupBox13)
        Me.GroupBox12.Controls.Add(Me.GroupBox4)
        Me.GroupBox12.Controls.Add(Me.GroupBox3)
        Me.GroupBox12.Controls.Add(Me.Button6)
        Me.GroupBox12.Controls.Add(Me.ListBox5)
        Me.GroupBox12.Controls.Add(Me.ListBox4)
        Me.GroupBox12.Controls.Add(Me.TextBox28)
        Me.GroupBox12.Controls.Add(Me.ListBox6)
        Me.GroupBox12.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox12.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(1339, 329)
        Me.GroupBox12.TabIndex = 123
        Me.GroupBox12.TabStop = False
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.Label23)
        Me.GroupBox13.Controls.Add(Me.TextBox66)
        Me.GroupBox13.Controls.Add(Me.RadioButton10)
        Me.GroupBox13.Controls.Add(Me.TextBox65)
        Me.GroupBox13.Controls.Add(Me.TextBox64)
        Me.GroupBox13.Controls.Add(Me.RadioButton9)
        Me.GroupBox13.Controls.Add(Me.RadioButton8)
        Me.GroupBox13.Controls.Add(Me.RadioButton7)
        Me.GroupBox13.Font = New System.Drawing.Font("Cambria", 16.0!)
        Me.GroupBox13.Location = New System.Drawing.Point(818, 107)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(469, 207)
        Me.GroupBox13.TabIndex = 123
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Constraints"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Cambria", 16.0!)
        Me.Label23.Location = New System.Drawing.Point(293, 40)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(70, 26)
        Me.Label23.TabIndex = 125
        Me.Label23.Text = "Limits"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox66
        '
        Me.TextBox66.Location = New System.Drawing.Point(237, 83)
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(208, 33)
        Me.TextBox66.TabIndex = 7
        '
        'RadioButton10
        '
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.Checked = True
        Me.RadioButton10.Location = New System.Drawing.Point(23, 40)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(80, 30)
        Me.RadioButton10.TabIndex = 6
        Me.RadioButton10.TabStop = True
        Me.RadioButton10.Text = "None"
        Me.RadioButton10.UseVisualStyleBackColor = True
        '
        'TextBox65
        '
        Me.TextBox65.Location = New System.Drawing.Point(237, 161)
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Size = New System.Drawing.Size(208, 33)
        Me.TextBox65.TabIndex = 5
        '
        'TextBox64
        '
        Me.TextBox64.Location = New System.Drawing.Point(237, 122)
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Size = New System.Drawing.Size(208, 33)
        Me.TextBox64.TabIndex = 4
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(17, 161)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(198, 30)
        Me.RadioButton9.TabIndex = 2
        Me.RadioButton9.Text = "Number of orders"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'RadioButton8
        '
        Me.RadioButton8.AutoSize = True
        Me.RadioButton8.Location = New System.Drawing.Point(18, 122)
        Me.RadioButton8.Name = "RadioButton8"
        Me.RadioButton8.Size = New System.Drawing.Size(178, 30)
        Me.RadioButton8.TabIndex = 1
        Me.RadioButton8.Text = "Inventory value"
        Me.RadioButton8.UseVisualStyleBackColor = True
        '
        'RadioButton7
        '
        Me.RadioButton7.AutoSize = True
        Me.RadioButton7.Location = New System.Drawing.Point(23, 83)
        Me.RadioButton7.Name = "RadioButton7"
        Me.RadioButton7.Size = New System.Drawing.Size(85, 30)
        Me.RadioButton7.TabIndex = 0
        Me.RadioButton7.Text = "Space"
        Me.RadioButton7.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange
        Me.ClientSize = New System.Drawing.Size(1356, 744)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.ListBox3)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.GroupBox12)
        Me.Name = "Form2"
        Me.Text = "Multiple item-EOQ"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox13 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox12 As System.Windows.Forms.ComboBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents ComboBox11 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox10 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox9 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox8 As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents r As System.Windows.Forms.Label
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents ListBox6 As System.Windows.Forms.ListBox
    Friend WithEvents RadioButton5 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton6 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ListBox5 As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents ListBox4 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents ListBox11 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox12 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox9 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox10 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox8 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox7 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox13 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox14 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox15 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox16 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox17 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox18 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox19 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox20 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox21 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox22 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox23 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox24 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox25 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox26 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox27 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox28 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox29 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox30 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox31 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox32 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox33 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox34 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox35 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox36 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox37 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox38 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox39 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox40 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox41 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox42 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox43 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox44 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox45 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox46 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox47 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox48 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox49 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox50 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox51 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox52 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox53 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox54 As System.Windows.Forms.ListBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents ListBox55 As System.Windows.Forms.ListBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents ComboBox14 As System.Windows.Forms.ComboBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton9 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton8 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton7 As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox65 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents RadioButton10 As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox66 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox67 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
End Class
